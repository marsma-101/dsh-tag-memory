// client.js —— 浏览器端的一半：设置 →「记忆」页。
//
// 格式是 DSH 的客户端模块加载器契约：本文件执行时只登记一个 factory，
// 真正的模块体（以及它注入的样式）要等模块被实例化才跑。React 来自平台
// 冻结的模块表，所以是 require 而不是 import。
//
// 挂在 `settings.section` 槽上：标签给设置导航，组件就是那一页。
// 数据全走 index.js 的只读 API（/tag-memory-api/*），本文件不碰磁盘。
window.__ModuleLoader__.load({
	id: 'dsh-tag-memory',
	factory: (require) => {
		var module = { exports: {} }
		var exports = module.exports

		const React = require('react')

		/** 与 index.js 的 ROUTE 一致。 */
		const API = '/tag-memory-api'
		/** 三处入口共用的 id：panellist 的 `id` 必须等于 main 面板的 `key`。 */
		const PANEL_ID = 'tag-memory'
		const SECTION_ID = PANEL_ID
		const SECTION_LABEL = '记忆'
		/** 侧边栏里的纵向位置：官方「插件」按钮是 0，排在它下面。 */
		const PANEL_ORDER = 5

		/** 详情里的字段顺序（只渲染非空项）。0.3.0 的 4 个新列排在末尾。 */
		const DETAIL_FIELDS = ['类型', '深度', '稳定性', '距离', '角色', '项目', '状态', '时间', '强度', '最后强化', '使用次数', '已验证项目', '环境', '原因', '依据', '关键词', '工具', '版本', '作用', '备注']
		/**
		 * 表格的列**照库自己的表头来**（`overview.header`），不另立一套——
		 * 库加一列，表格就多一列。这份只在 overview 还没回来时兜底。
		 */
		const FALLBACK_HEADER = ['id', '内容', '时间', '环境', '原因', '备注', '稳定性', '成熟度', '距离', '角色', '项目', '状态', '关键词', '工具', '版本', '依据', '类型', '强度', '最后强化', '已验证项目', '使用次数']
		/**
		 * 0.3.0 新增的 4 列。列设置里照实列出来，但**本库表头还没有它们时**（老库 17 列）
		 * 摆成不可勾的「未落列」——勾了也不会有值，那就是骗人。表头迁移后自动可勾。
		 */
		const NEW_COLUMNS = ['强度', '最后强化', '已验证项目', '使用次数']
		/**
		 * 默认摆出来的列。挑的是「一行看得完」的；环境/原因/备注/工具/版本/依据
		 * 这些长文本或常空的留在「详情」里，想要也能在「列设置」里勾出来。
		 *
		 * `强度` 摆进来：它短（0~1），又是待整理区的判据，一眼看得到衰到哪儿了。
		 * 另外三个默认不摆——`最后强化`/`已验证项目` 偏长，`使用次数` 常看不着；
		 * 要的就在列设置里勾，勾选会记住。
		 */
		const DEFAULT_COLUMNS = ['id', '内容', '时间', '类型', '稳定性', '强度', '成熟度', '距离', '角色', '项目', '状态', '关键词']
		/** 列的显示宽窄：mono 等宽（id/时间）、wide 放宽（长文本）、其余按内容自适应。 */
		const COLUMN_KIND = {
			id: 'mono', 时间: 'mono', 最后强化: 'mono',
			内容: 'wide', 环境: 'wide', 原因: 'wide', 备注: 'wide', 关键词: 'wide', 已验证项目: 'wide',
		}
		/** 表格单元格里长文本的截断长度（够看个大概，全文走 title 与「详情」）。 */
		const CELL_CLIP = 56
		/** 正文超过这么多字先折叠。 */
		const CONTENT_CLIP = 120
		const PAGE_SIZES = [20, 50, 100, 200]
		/**
		 * 排序档。缺省是「id ↓」——库是只追加的，id 里的日期 + 序号就是写入次序，
		 * 倒过来放＝**最新写的在最上面**，一眼看得到新加的是什么。
		 * 「最近加入」看的是文件顺序：并库进来的条目 id 带着来源那边的日期，按 id 排会插回老位置，
		 * 想看「这一趟新进来的」就用那一档。
		 */
		const SORTS = [
			['id_desc', 'id ↓（新 → 旧）'],
			['file_desc', '最近加入（含并库）'],
			['time_desc', '时间 ↓'],
			['time_asc', '时间 ↑'],
			['id_asc', 'id ↑（旧 → 新）'],
		]
		/** 旧宿主只认这四档——它不报 `overview.sorts`，不知道「最近加入」是什么。 */
		const SORTS_LEGACY = ['id_desc', 'time_desc', 'time_asc', 'id_asc']
		/** 状态的兜底全集——overview 还没回来时用。 */
		const STATUS_FALLBACK = ['生效', '被取代', '已归档']
		const asArr = (x) => (Array.isArray(x) ? x : [x])
		/** 视图偏好（条件/排序/每页数）的本地记忆键。 */
		const STORE_KEY = 'dsh-tag-memory:view'
		/**
		 * 视图偏好的存档版本。**改了缺省值就得 +1**：存档里连「用户没动过的缺省」也一并写着，
		 * 不换版本号的话，旧缺省（时间 ↓）会一直压着新缺省，改了等于没改。
		 */
		const STORE_VERSION = 2

		/** 读取上次的视图偏好；隐私模式等拿不到就返回 null。 */
		function loadView() {
			try {
				const raw = window.localStorage.getItem(STORE_KEY)
				if (raw === null) return null
				const parsed = JSON.parse(raw)
				if (parsed === null || typeof parsed !== 'object') return null
				// 老存档的「排序」那一格存的是**当时的缺省**（时间 ↓）——用户根本没动过下拉，
				// 可存档里就是写着它。版本对不上就把这一格丢掉（其余偏好照旧），否则新缺省顶不动它。
				if (parsed.v !== STORE_VERSION) return { ...parsed, sort: undefined }
				return parsed
			} catch { return null }
		}

		const CSS = `
.tm-root{box-sizing:border-box;display:flex;flex-direction:column;gap:14px;padding:4px 2px 20px;
  color:var(--dsw-alias-label-primary)}
/* 主区页面（main 槽）。shell 的 .centerCol 是 flex column + overflow:hidden 且有确定高度，
   自己不滚 —— 面板必须自己当滚动容器，否则内容超出就被裁掉（见 ui-plugin-manager 的 .page）。
   顶部再让出窗口顶带（--dsh-frame-top-clearance），免得第一行压在标题栏/红绿灯下面。 */
.tm-panel{box-sizing:border-box;width:100%;height:100%;overflow:auto;scrollbar-gutter:stable;
  padding:calc(20px + var(--dsh-frame-top-clearance,0px)) clamp(24px,4vw,48px) 40px}
.tm-panel>.tm-root{max-width:1200px;margin:0 auto}
.tm-head{margin:0;font-size:16px;font-weight:700;line-height:24px}
.tm-sub{font-size:12px;color:var(--dsw-alias-label-secondary);margin-top:-8px;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tm-stats{display:flex;flex-wrap:wrap;gap:10px}
.tm-stat{flex:1 1 120px;min-width:110px;padding:12px 14px;border-radius:12px;
  background:var(--dsw-alias-interactive-bg-hover)}
.tm-stat-n{font-size:20px;font-weight:700;line-height:1.2}
.tm-stat-l{font-size:12px;color:var(--dsw-alias-label-secondary);margin-top:2px}
.tm-card{padding:14px 16px;border-radius:12px;
  background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-base));
  box-shadow:inset 0 0 0 1px var(--dsw-alias-separator,rgba(127,127,127,.18))}
.tm-card-h{display:flex;align-items:center;gap:10px;margin-bottom:10px}
.tm-card-t{margin:0;font-size:13px;font-weight:600;flex:auto}
.tm-note{font-size:12px;line-height:1.6;color:var(--dsw-alias-label-secondary)}
.tm-err{color:var(--dsw-alias-label-error,inherit)}
.tm-memrow{display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:8px;
  font:12px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  background:var(--dsw-alias-interactive-bg-hover);margin-bottom:6px}
.tm-dot{flex:none;width:8px;height:8px;border-radius:999px;background:var(--dsw-alias-label-secondary)}
.tm-dot[data-ok]{background:#39b54a}
.tm-dot[data-missing]{background:#e0a800}
.tm-memrow .tm-tag{margin-left:auto;font:11px/1.4 inherit;color:var(--dsw-alias-label-secondary)}
.tm-btn{flex:none;height:28px;padding:0 14px;border:none;border-radius:8px;cursor:pointer;
  font:inherit;font-size:12px;font-weight:600;color:var(--dsw-alias-label-primary);
  background:var(--dsw-alias-interactive-bg-active)}
.tm-btn:hover{background:var(--dsw-alias-interactive-bg-hover)}
.tm-btn[disabled]{opacity:.5;cursor:default}
.tm-field{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.tm-input{flex:1 1 200px;min-width:160px;height:32px;padding:0 12px;box-sizing:border-box;
  border:1px solid var(--dsw-alias-separator,rgba(127,127,127,.22));border-radius:8px;
  background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-base));color:inherit;font:inherit;font-size:13px}
.tm-select{height:32px;padding:0 8px;border-radius:8px;font:inherit;font-size:13px;
  border:1px solid var(--dsw-alias-separator,rgba(127,127,127,.22));
  background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-base));color:inherit}
/* 维度筛选：一个维度一个下拉，横向排一行，不再一个维度占一大块。 */
.tm-filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.tm-fsel{max-width:180px}
.tm-chip{height:24px;padding:0 10px;border:none;border-radius:999px;cursor:pointer;
  font:inherit;font-size:12px;color:var(--dsw-alias-label-secondary);
  background:var(--dsw-alias-interactive-bg-hover);display:inline-flex;align-items:center;gap:6px}
.tm-chip:hover{color:var(--dsw-alias-label-primary)}
.tm-chip[data-on]{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-active);font-weight:600}
.tm-list{display:flex;flex-direction:column;gap:8px}
.tm-item{padding:10px 12px;border-radius:10px;background:var(--dsw-alias-interactive-bg-hover)}
.tm-item-h{display:flex;gap:8px;align-items:baseline}
.tm-id{flex:none;font:11px/1.6 ui-monospace,Menlo,Consolas,monospace;color:var(--dsw-alias-label-secondary)}
.tm-content{font-size:13px;line-height:1.6;word-break:break-word}
.tm-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.tm-mtag{padding:1px 8px;border-radius:999px;font-size:11px;
  color:var(--dsw-alias-label-secondary);box-shadow:inset 0 0 0 1px var(--dsw-alias-separator,rgba(127,127,127,.25))}
.tm-mtag b{font-weight:600;color:var(--dsw-alias-label-primary)}
/* 外部来源角标（评审卡 kmvnul5xkdg1l）：它不是「普通标签」，是「这条不是用户说的」的警示。
   用琥珀色描边+同色字，和灰色普通标签区分开；不铺满底色，免得比正文还抢眼。 */
.tm-mtag-ext{color:#b8860b;box-shadow:inset 0 0 0 1px rgba(184,134,11,.55);font-weight:600}
.tm-link{border:none;background:none;padding:0;margin-left:6px;cursor:pointer;
  font:inherit;font-size:12px;color:var(--dsw-alias-label-primary);opacity:.75;text-decoration:underline}
.tm-link:hover{opacity:1}
.tm-detail-btn{display:block;margin-top:6px}
.tm-actions{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin-top:6px}
.tm-actions .tm-link{margin-left:0}
.tm-detail{margin-top:8px;padding-top:8px;display:grid;grid-template-columns:auto 1fr;gap:4px 12px;
  font-size:12px;line-height:1.6;border-top:1px solid var(--dsw-alias-separator,rgba(127,127,127,.18))}
.tm-detail-k{color:var(--dsw-alias-label-secondary);white-space:nowrap}
.tm-detail-note{color:var(--dsw-alias-label-secondary);font-size:11px}
.tm-detail-v{word-break:break-word}
.tm-more{display:block;width:100%;height:32px;margin-top:10px;border:none;border-radius:8px;
  cursor:pointer;font:inherit;font-size:12px;font-weight:600;color:var(--dsw-alias-label-primary);
  background:var(--dsw-alias-interactive-bg-hover)}
.tm-more:hover:not([disabled]){background:var(--dsw-alias-interactive-bg-active)}
.tm-more[disabled]{opacity:.55;cursor:default}
.tm-crumbs{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:10px}
.tm-crumb{display:inline-flex;align-items:center;padding:2px 4px 2px 10px;border-radius:999px;font-size:12px;
  color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-active)}
.tm-crumb-x{border:none;background:none;padding:0 4px;cursor:pointer;font:inherit;font-size:13px;line-height:1;
  color:var(--dsw-alias-label-secondary)}
.tm-crumb-x:hover{color:var(--dsw-alias-label-primary)}
.tm-check{flex:none;width:14px;height:14px;margin:0;cursor:pointer}
/* ── 表格视图 ── 自己滚：横向列多，纵向配 sticky 表头。 */
.tm-tablewrap{overflow:auto;overscroll-behavior:contain;max-height:min(68vh,860px);border-radius:10px;
  box-shadow:inset 0 0 0 1px var(--dsw-alias-separator,rgba(127,127,127,.18))}
.tm-table{border-collapse:separate;border-spacing:0;width:100%;font-size:12px;line-height:1.6}
.tm-table th,.tm-table td{padding:5px 9px;text-align:left;vertical-align:top;white-space:nowrap;
  border-bottom:1px solid var(--dsw-alias-separator,rgba(127,127,127,.14))}
.tm-table thead th{position:sticky;top:0;z-index:1;font-weight:600;white-space:nowrap;
  background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-base));
  border-bottom:1px solid var(--dsw-alias-separator,rgba(127,127,127,.32))}
.tm-table tbody tr:hover{background:var(--dsw-alias-interactive-bg-hover)}
.tm-table tbody tr:last-child td{border-bottom:none}
.tm-col-check{width:1%}
.tm-td-id{font:11px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  color:var(--dsw-alias-label-secondary)}
.tm-clip{display:block;max-width:32ch;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tm-clip-wide{max-width:52ch}
.tm-td-ops{white-space:nowrap}
.tm-td-ops .tm-link{margin-left:0;margin-right:12px}
.tm-td-ops .tm-link:last-child{margin-right:0}
.tm-tr-detail>td{white-space:normal;background:var(--dsw-alias-interactive-bg-hover)}
.tm-tools{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
.tm-count{font-size:12px;color:var(--dsw-alias-label-secondary)}
/* 列设置（V4-f）：设置类的东西，收起时不占地方，展开也只是表格上方一条。 */
.tm-colpick{margin-bottom:10px;padding:10px 12px;border-radius:10px;
  background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-base));
  box-shadow:inset 0 0 0 1px var(--dsw-alias-separator,rgba(127,127,127,.18))}
.tm-colpick-h{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px}
.tm-colpick-h>.tm-note{flex:auto}
.tm-colpick-list{display:flex;flex-wrap:wrap;gap:6px 14px}
.tm-colpick-item{display:inline-flex;align-items:center;gap:6px;font-size:12px;line-height:1.8;cursor:pointer}
.tm-colpick-item[data-off]{opacity:.5;cursor:default}
.tm-colpick-item[data-new] .tm-mtag{color:var(--dsw-alias-label-secondary)}
/* 待整理区的批量操作条：全选 + 归档所选 + 进度，都摆在候选清单**上面**。 */
.tm-batchbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:6px 0 8px}
.tm-batchbar>.tm-count{flex:auto}
/* 待整理/待晋升的行：勾选 + id + 强度 + 内容预览 + 按钮。
   不复用 .tm-bkrow 的 margin-left:auto（那是给备份行把标签推到右边的），
   这里内容是主体，要占住中间。 */
.tm-prow{display:flex;align-items:center;gap:8px;padding:5px 0;font-size:12px;line-height:1.6;
  border-top:1px solid var(--dsw-alias-separator,rgba(127,127,127,.14))}
.tm-prow:first-of-type{border-top:none}
.tm-prow .tm-mono{flex:none;font:11px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  color:var(--dsw-alias-label-secondary)}
.tm-prow .tm-tag{flex:none;padding:1px 8px;border-radius:999px;font-size:11px;
  background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}
.tm-prow .tm-preview{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tm-prow .tm-link{flex:none}

/* ── 备份 / 恢复 / 合并 ──
   按钮不另占一张卡：跟标题同一行，右对齐 —— 主位留给「要看的条目」。 */
.tm-headrow{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.tm-headrow>.tm-head{flex:auto;margin:0}
.tm-barbtns{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.tm-bkline{font-size:12px;line-height:1.6;color:var(--dsw-alias-label-secondary);
  display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.tm-bkline b{font-weight:600;color:var(--dsw-alias-label-primary)}
.tm-bkline>span{overflow-wrap:anywhere}
.tm-warn{color:#e0a800}
.tm-ok{color:#39b54a}
.tm-bad{color:var(--dsw-alias-label-error,inherit)}
.tm-pane{margin-top:10px;padding:12px 14px;border-radius:12px;
  background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-base));
  box-shadow:inset 0 0 0 1px var(--dsw-alias-separator,rgba(127,127,127,.18))}
.tm-pane-h{display:flex;align-items:center;gap:10px;margin-bottom:8px}
.tm-pane-t{margin:0;font-size:13px;font-weight:600;flex:auto}
/* 内建目录浏览：系统选择框弹不出来时的兜底 */
.tm-browse{margin-top:10px;padding:10px;border-radius:10px;
  background:var(--dsw-alias-bg-base,transparent);
  box-shadow:inset 0 0 0 1px var(--dsw-alias-separator,rgba(127,127,127,.18))}
.tm-crumbs{display:flex;flex-wrap:wrap;align-items:center;gap:2px;font-size:12px;margin-bottom:8px}
.tm-crumb-wrap{display:inline-flex;align-items:center;gap:2px}
.tm-crumb-sep{color:var(--dsw-alias-label-secondary);opacity:.6}
.tm-crumb{border:none;background:none;padding:2px 6px;border-radius:6px;cursor:pointer;
  font:inherit;font-size:12px;color:var(--dsw-alias-label-primary)}
.tm-crumb:hover{background:var(--dsw-alias-interactive-bg-hover)}
.tm-browse-list{display:flex;flex-wrap:wrap;gap:6px;max-height:200px;overflow:auto}
.tm-dir{flex:0 1 auto;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  height:26px;padding:0 10px;border:none;border-radius:8px;cursor:pointer;font:inherit;font-size:12px;
  background:var(--dsw-alias-interactive-bg,var(--dsw-alias-bg-overlay));
  color:var(--dsw-alias-label-primary)}
.tm-dir:hover{background:var(--dsw-alias-interactive-bg-hover)}
.tm-bkrow{display:flex;align-items:center;gap:10px;padding:6px 0;font-size:12px;line-height:1.6;
  border-top:1px solid var(--dsw-alias-separator,rgba(127,127,127,.14))}
.tm-bkrow:first-of-type{border-top:none}
.tm-bkrow .tm-mono{font:11px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
.tm-bkrow .tm-tag{margin-left:auto}
.tm-fold{border:none;background:none;padding:0;cursor:pointer;font:inherit;font-size:12px;
  color:var(--dsw-alias-label-secondary);display:inline-flex;align-items:center;gap:6px}
.tm-fold:hover{color:var(--dsw-alias-label-primary)}
.tm-kv{display:flex;flex-direction:column;gap:4px;font-size:12px;line-height:1.6}
.tm-kv-row{display:grid;grid-template-columns:auto 1fr;gap:12px}
.tm-kv-k{color:var(--dsw-alias-label-secondary);white-space:nowrap}
.tm-kv-v{word-break:break-word}

/* ── 标签字典（设置页那份只读展示）──
   一个取值一行：左边是取值本身，右边是「它是什么意思、什么时候用它」。 */
.tm-dict-lead{font-size:12px;line-height:1.6}
.tm-dict-item{display:flex;gap:10px;align-items:baseline;padding:6px 0;font-size:12px;line-height:1.6}
.tm-dict-item+.tm-dict-item{border-top:1px solid var(--dsw-alias-separator,rgba(127,127,127,.14))}
.tm-dict-val{flex:none;font-weight:600;white-space:nowrap}
.tm-dict-desc{flex:1 1 auto;color:var(--dsw-alias-label-secondary);word-break:break-word}
.tm-dict-rule{flex:none;font:11px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  color:var(--dsw-alias-label-secondary)}
`

		/**
		 * 样式表在插件 apply 时注入一次，并把移除函数交给 ctx.effect 管理。
		 * 不能从页面组件的 useEffect 里偷偷往 document.head 塞节点：设置页和主区
		 * 可能先后挂载，而卸载/HMR 时又没人回收。apply 层统一负责生命周期。
		 */
		function ensureStyles() {
			// Node 侧做槽位冒烟时没有 DOM；浏览器里才是真资源。
			if (typeof document === 'undefined') return () => {}
			let tag = document.getElementById('dsh-tag-memory-css')
			if (tag === null || tag.tagName !== 'STYLE') {
				tag = document.createElement('style')
				tag.id = 'dsh-tag-memory-css'
				document.head.appendChild(tag)
			}
			tag.textContent = CSS
			return () => { if (tag.parentNode !== null) tag.parentNode.removeChild(tag) }
		}

		/**
		 * 把服务端的原始错误译成人话。
		 *
		 * **`unknown op "/xxx"` = 宿主的版本比界面旧**：DSH 只在**启动时**装载插件的服务端半边，
		 * 而客户端模块会**热更**——所以很容易出现「界面已经是新版、路由表还是老版」。
		 * 这时任何新加的路由都会回 `unknown op`，把这句话直接甩给用户，人只会一头雾水
		 * （真踩过：新界面调 `POST /backup/dir` 存地址，旧宿主没这条路，界面弹的是一句
		 * `unknown op "/backup/dir"`，看着像自己填错了）。
		 */
		function humanError(raw, url) {
			const text = String(raw ?? '')
			if (/unknown op/.test(text)) {
				const op = String(url ?? '').replace(/^.*\/tag-memory-api/, '') || '这条'
				return `这台 DSH 的服务端还是旧版（路由表里没有 ${op}）——界面已经更新，重启一次 DSH 就好。`
			}
			return text
		}

		/** 取一份 JSON；网络/非 JSON 都抛成人话。 */
		async function loadJSON(url, init) {
			const response = await fetch(url, {
				headers: { accept: 'application/json' },
				...init,
			})
			const data = await response.json()
			if (data && data.error !== undefined && data.error !== null) throw new Error(humanError(data.error, url))
			return data
		}

		/**
		 * POST 一份 JSON 并**原样**拿回结果。
		 * 备份/恢复/合并这几个接口把「失败」也当事返回（`{ok:false, code, error}`），
		 * 界面要按 code 分派（比如 NO_DIR 就切进设置地址的状态），所以这里不替它抛。
		 */
		async function postJSON(url, body) {
			const response = await fetch(url, {
				method: 'POST',
				headers: { accept: 'application/json', 'content-type': 'application/json' },
				body: JSON.stringify(body ?? {}),
			})
			let data
			try { data = await response.json() } catch {
				throw new Error(`服务端没回 JSON（HTTP ${response.status}）`)
			}
			// 失败也照样返回（调用方按 code 分派），只把 `unknown op` 这种协议黑话先译成人话。
			if (data !== null && typeof data === 'object' && typeof data.error === 'string') {
				data.error = humanError(data.error, url)
			}
			return data
		}

		/** 字节数说成人话。 */
		function humanBytes(n) {
			if (n === null || n === undefined || !Number.isFinite(n)) return ''
			const units = ['B', 'KB', 'MB', 'GB', 'TB']
			let v = n, i = 0
			while (v >= 1024 && i < units.length - 1) { v /= 1024; i++ }
			return `${i === 0 ? v : v.toFixed(v >= 10 ? 0 : 1)} ${units[i]}`
		}

		/** `2026-10-14T08:42:03+08:00` → `2026-10-14 08:42`。 */
		function shortTime(text) {
			const s = String(text ?? '')
			return s.length >= 16 ? `${s.slice(0, 10)} ${s.slice(11, 16)}` : s
		}

		function Stat(props) {
			return React.createElement(
				'div',
				{ className: 'tm-stat' },
				React.createElement('div', { className: 'tm-stat-n' }, props.value),
				React.createElement('div', { className: 'tm-stat-l' }, props.label),
			)
		}

		/**
		 * 设置里的「记忆」页：库概况 + 按维度浏览 + 关键词搜 + 记忆文件托管状态。
		 * 只读——写入由智能体通过 memory_write 工具做。
		 */
		function MemorySection(props) {
			const [overview, setOverview] = React.useState(null)
			const [items, setItems] = React.useState([])
			const [total, setTotal] = React.useState(0)
			const [hasMore, setHasMore] = React.useState(false)
			const [loading, setLoading] = React.useState(true)
			const [loadingMore, setLoadingMore] = React.useState(false)
			const [saved] = React.useState(() => loadView() ?? {})
			const [q, setQ] = React.useState('')
			const [cond, setCond] = React.useState(() => (saved.cond !== null && typeof saved.cond === 'object' ? saved.cond : {}))
			const [limit, setLimit] = React.useState(() => (typeof saved.limit === 'number' && PAGE_SIZES.includes(saved.limit) ? saved.limit : 50))
			const [sort, setSort] = React.useState(() => (SORTS.some(([value]) => value === saved.sort) ? saved.sort : 'id_desc'))
			const [includeArchived, setIncludeArchived] = React.useState(() => saved.includeArchived === true)
			/**
			 * 表格 / 卡片两种视图。默认值看宿主：主区宽，给表格；设置页窄，给卡片。
			 * localStorage 里存过就听用户的。
			 */
			const fallbackView = props !== null && props !== undefined && props.defaultView === 'cards' ? 'cards' : 'table'
			const [view, setView] = React.useState(() => (saved.view === 'cards' || saved.view === 'table' ? saved.view : fallbackView))
			const [expanded, setExpanded] = React.useState({})
			const [fullText, setFullText] = React.useState({})
			const [selected, setSelected] = React.useState({})
			const [tip, setTip] = React.useState('')
			const searchRef = React.useRef(null)

			// 键盘：`/` 聚焦搜索框，`Esc` 清空全部条件与关键词。
			React.useEffect(() => {
				function onKey(event) {
					const target = event.target
					const tag = target !== null && target !== undefined ? target.tagName : ''
					const typing = tag === 'INPUT' || tag === 'TEXTAREA' || target?.isContentEditable === true
					if (event.key === '/' && !typing) {
						event.preventDefault()
						if (searchRef.current !== null) searchRef.current.focus()
						return
					}
					if (event.key === 'Escape') {
						setCond({})
						setIncludeArchived(false)
						setQ('')
					}
				}
				window.addEventListener('keydown', onKey)
				return () => window.removeEventListener('keydown', onKey)
			}, [])
			const [error, setError] = React.useState(null)
			const [busy, setBusy] = React.useState(false)
			const [note, setNote] = React.useState('')

			// ── 备份 / 恢复 / 合并 ──
			const [bk, setBk] = React.useState(null)
			/** 正在跑的备份动作（'' | 'backup' | 'dir' | 'restore' | 'merge'），按钮据此转圈。 */
			const [bkBusy, setBkBusy] = React.useState('')
			const [bkNote, setBkNote] = React.useState(null)
			/** 设置备份地址那一小块。没地址时点「立即备份」会把它打开——降级，不是弹提醒。 */
			const [dirOpen, setDirOpen] = React.useState(false)
			const [dirValue, setDirValue] = React.useState('')
			/** 系统文件夹选择框开着的时候为 true（它一次只能开一个）。 */
			const [pickerBusy, setPickerBusy] = React.useState(false)
			/** 系统框拿不到时的兜底：内建目录浏览（listDirectory 给的一层）。 */
			const [browse, setBrowse] = React.useState(null)
			const [browseBusy, setBrowseBusy] = React.useState(false)
			const dirRef = React.useRef(null)
			const [restoreOpen, setRestoreOpen] = React.useState(false)
			const [mergeOpen, setMergeOpen] = React.useState(false)
			const [mergePath, setMergePath] = React.useState('')
			/**
			 * 「我确认这是可信来源」——后端 R-7 的准入闸。
			 *
			 * 来源路径不在备份目录/库目录之下时，后端会回 `SOURCE_OUTSIDE`。没有这个勾选框，
			 * 界面就等于「永远拒绝」，那道闸反而成了坏功能。勾上后**预演与真合并都要带上**，
			 * 否则预演放行、真合并又被拒一次，用户会以为合并坏了。
			 *
			 * 用 `useRef` 而不是 `useState`：勾选框的选中态由 DOM 自己持有，这里只需要在
			 * 点击时读到「此刻勾没勾」。少一个 state 就少一个 hook 序号，也就不会把
			 * 别的 state（以及自检里按序号预置的取值）整体挤位。
			 */
			const mergeConfirmedRef = React.useRef(false)
			const [mergeReport, setMergeReport] = React.useState(null)
			/** 维护区（托管状态 + 备份历史）默认收起——次位的东西不占主显示区。 */
			const [maintOpen, setMaintOpen] = React.useState(false)
			/** 改号 → 重新取第一页（恢复 / 合并换过库之后要重读）。 */
			const [reloadKey, setReloadKey] = React.useState(0)
			const reloadEntries = () => setReloadKey((k) => k + 1)

			/**
			 * 概况（含维度取值、计数、待整理/待晋升清单），挂载时取一次；
			 * **`reloadKey` 变了一次重取**——归档/取代/批量归档改完库，这两块必须跟着变，
			 * 否则「归档了 3 条，待整理还摆着那 3 条」——用户会以为没生效，再点一次。
			 */
			React.useEffect(() => {
				let alive = true
				loadJSON(`${API}/overview`)
					.then((data) => { if (alive) setOverview(data) })
					.catch((failure) => { if (alive) setError(String((failure && failure.message) || failure)) })
				return () => { alive = false }
			}, [reloadKey])

			/**
			 * 实发条件：开了「含已归档」就把**全部状态取值 + 留白**显式写进去——
			 * core 只在条件「没提状态」时才默认排除 被取代/已归档，显式写了就不排除。
			 */
			const statusAll =
				overview !== null && Array.isArray(overview.statusValues) && overview.statusValues.length > 0
					? overview.statusValues
					: STATUS_FALLBACK
			const effectiveCond = (function () {
				const next = { ...cond }
				if (includeArchived) {
					const base = next['状态'] !== undefined ? asArr(next['状态']) : statusAll.concat('留白')
					next['状态'] = Array.from(new Set(base.concat(['被取代', '已归档'])))
				}
				return next
			})()
			const condKey = JSON.stringify(effectiveCond)

			/**
			 * 宿主认哪几档排序：`overview.sorts` 说得很清楚就听它的；没这一项＝旧宿主，
			 * 只摆它认得的四档（新档在旧宿主上不会报错，它只是**当没看见**，照样返回原序——
			 * 那才是最坏的一种坏：不报错、结果不对）。
			 */
			const hostSorts = overview !== null && Array.isArray(overview.sorts) ? overview.sorts : SORTS_LEGACY
			const sortOptions = SORTS.filter(([value]) => hostSorts.includes(value))
			/** 存档里的档位宿主不认（用户在旧版上选过新档）→ 退回 id ↓，别让下拉摆个空值。 */
			const effSort = sortOptions.some(([value]) => value === sort) ? sort : 'id_desc'

			/** 拼一页的查询串；offset=0 即首页。 */
			function pageQuery(offset) {
				const params = new URLSearchParams()
				if (condKey !== '{}') params.set('cond', condKey)
				if (q.trim() !== '') params.set('q', q.trim())
				params.set('sort', effSort)
				params.set('limit', String(limit))
				params.set('offset', String(offset))
				return params.toString()
			}

			// 条件/关键词/排序/每页数一变就回到首页重取。
			React.useEffect(() => {
				let alive = true
				setLoading(true)
				loadJSON(`${API}/entries?${pageQuery(0)}`)
					.then((result) => {
						if (!alive) return
						setItems(Array.isArray(result.hits) ? result.hits : [])
						setTotal(result.total ?? 0)
						setHasMore(result.hasMore === true)
						setError(null)
					})
					.catch((failure) => { if (alive) setError(String((failure && failure.message) || failure)) })
					.finally(() => { if (alive) setLoading(false) })
				return () => { alive = false }
			}, [condKey, q, limit, effSort, reloadKey])

			/** 「加载更多」：从已示条数接着取下一页。 */
			async function loadMore() {
				setLoadingMore(true)
				try {
					const result = await loadJSON(`${API}/entries?${pageQuery(items.length)}`)
					setItems((prev) => prev.concat(Array.isArray(result.hits) ? result.hits : []))
					setTotal(result.total ?? 0)
					setHasMore(result.hasMore === true)
				} catch (failure) {
					setError(String((failure && failure.message) || failure))
				} finally {
					setLoadingMore(false)
				}
			}

			async function heal() {
				setBusy(true)
				setNote('')
				try {
					const result = await loadJSON(`${API}/heal`, { method: 'POST' })
					setOverview((prev) => (prev === null ? prev : { ...prev, notice: result.notice }))
					const s = result.summary ?? {}
					setNote(s.written > 0 ? `已补写 ${s.written} 个记忆文件的说明块` : `说明块均在位（核对了 ${s.checked ?? 0} 个）`)
				} catch (failure) {
					setNote(`自愈失败：${String((failure && failure.message) || failure)}`)
				} finally {
					setBusy(false)
				}
			}

			// ── 备份 / 恢复 / 合并的动作 ────────────────────

			/** 拉一次备份现状。只读，进来就拉。 */
			async function refreshBackup() {
				try {
					const data = await loadJSON(`${API}/backup`)
					setBk(data)
				} catch (failure) {
					setBk({ available: false, error: String((failure && failure.message) || failure) })
				}
			}

			React.useEffect(() => {
				let alive = true
				loadJSON(`${API}/backup`)
					.then((data) => { if (alive) setBk(data) })
					.catch((failure) => { if (alive) setBk({ available: false, error: String((failure && failure.message) || failure) }) })
				return () => { alive = false }
			}, [])

			/** 宿主给的目录选择能力（由 apply 注入；拿不到就是 null，走兜底）。 */
			const hostPick = typeof props?.pickDir === 'function' ? props.pickDir : null
			const hostList = typeof props?.listDir === 'function' ? props.listDir : null

			/**
			 * 这台 DSH 的目录选择是**哪一套后端**——问宿主（`/tag-memory-api/picker`）。
			 *
			 * 两套是**互斥**的，开机时定死：`native` 只响应 `pickDirectory()`（弹系统框），
			 * `browse` 只响应 `listDirectory()`（列目录）。所以「哪颗按钮有用」不是偏好问题，
			 * 是这台机器的事实——问清楚再决定点哪个，别去撞那扇注定关着的门。
			 * `null` = 还没问出来（或老宿主没有这条路由），此时按老办法：先试系统框，失败了再兜底。
			 */
			const [pickerKind, setPickerKind] = React.useState(null)
			/**
			 * ── V4 前端三件（d/e/f）的 state ─────────────────────
			 * **必须放在这里**：自检的渲染冒烟按 useState 的调用序号预置取值，
			 * 插在中间会把后面所有 state 整体挤位、测出来的版式不是用户看到的那个。
			 * 新增一律追加在最后一个 state（pickerKind）之后。
			 */
			/** V4-f 列设置：勾了哪些列（列名）。空 = 用默认那拨。 */
			const [columnsPicked, setColumnsPicked] = React.useState(() => (Array.isArray(saved.columns) ? saved.columns.filter((c) => typeof c === 'string') : null))
			/** 列设置面板开没开。默认收起——它是「设置」，按主位通则不占正文。 */
			const [colOpen, setColOpen] = React.useState(false)
			/** V4-e 待整理区勾选的 id 表 `{id: true}`。 */
			const [pendingSel, setPendingSel] = React.useState({})
			/** V4-e 批量归档的进度/结果：`null` = 没在跑；`{done,total}` = 跑到第几条。 */
			const [batch, setBatch] = React.useState(null)
			/** V4-e 批量归档的收尾话（成功 N / 失败 M + 失败清单）。 */
			const [batchNote, setBatchNote] = React.useState(null)
			/**
			 * 批量归档里「不是候选、被四判据拦下」的那些（评审卡 kmvnul5t1k2p8）。
			 *
			 * 后端 `requireCandidate` 默认 true 之后，待整理清单里只要有一条**刚被强化过**
			 * （用户点刷新之前强度回升），它就会被拒。这些**不该混进「失败」**——
			 * 不是出错，是「按规矩不该归档」。跑完单独摆出来，用户点头才强制重发。
			 */
			const [batchRejected, setBatchRejected] = React.useState(null)
			/**
			 * 盘点清单（`GET /review` 的四张 + 批B 的「召回失败未补」）。
			 *
			 * 为什么界面上要有：这些清单原先只有智能体通过 `memory_review({类型:'盘点'})`
			 * 才看得到，用户不打开工具就不知道库里有多少东西该整理。界面给一个入口，
			 * 让人自己也能盘点。**只读**——动作仍走归档/取代那颗按钮。
			 *
			 * `null` = 还没取；`{ok:false}` = 取失败（旧宿主可能没这条路由）。
			 */
			const [review, setReview] = React.useState(null)
			/** 盘点区开没开。默认收起：它是「整理」不是「日常要看的」。 */
			const [reviewOpen, setReviewOpen] = React.useState(false)

			// 视图偏好落本地，重开设置页还在。
			// **放在这批 state 之后**：它要用 `columnsPicked`，挪到前面就是「用了还没声明的变量」。
			React.useEffect(() => {
				try {
					window.localStorage.setItem(STORE_KEY, JSON.stringify({ v: STORE_VERSION, cond, sort, limit, includeArchived, view, columns: columnsPicked }))
				} catch { /* 隐私模式/配额，忽略 */ }
			}, [cond, sort, limit, includeArchived, view, columnsPicked])

			React.useEffect(() => {
				let alive = true
				loadJSON(`${API}/picker`)
					.then((data) => { if (alive) setPickerKind(typeof data?.kind === 'string' ? data.kind : null) })
					.catch(() => { /* 问不出来就按未知处理，不影响别的 */ })
				return () => { alive = false }
			}, [])

			/**
			 * 盘点清单：只在**展开时才取**（默认收起）。不展开就不发这个请求——
			 * 它是整理用的，不是每次进页面都要的。`reloadKey` 变了重取（归档后清单要跟着变）。
			 */
			React.useEffect(() => {
				if (!reviewOpen) return undefined
				let alive = true
				loadJSON(`${API}/review`)
					.then((data) => { if (alive) setReview(data) })
					.catch((failure) => { if (alive) setReview({ ok: false, error: String((failure && failure.message) || failure) }) })
				return () => { alive = false }
			}, [reviewOpen, reloadKey])

			/**
			 * 面板开着时，**「现在存着的地址」一变就摆进格子**。
			 *
			 * 这条是「选完就丢」的另一半病根：格子原来恒从空串起步，重开面板 / 刷新后
			 * 明明 `backup.json` 里存着地址，格子里却是空的——看着就像没存上。
			 * 现在格子跟着**库里真正存着的那个值**走（`bk.dir` 来自宿主，进来就拉）。
			 * 只在没有保存动作进行时同步，免得打断正在手输的内容。
			 */
			React.useEffect(() => {
				if (!dirOpen || bkBusy !== '') return
				setDirValue(typeof bk?.dir === 'string' ? bk.dir : '')
			}, [dirOpen, bk?.dir, bkBusy])

			/** 点「设置备份地址」——把面板打开，并直接弹系统的「选择文件夹」框。 */
			function openDirForm() {
				setDirOpen(true)
				setBkNote(null)
				try { window.setTimeout(() => dirRef.current?.focus(), 0) } catch { /* 没有 ref 就算了 */ }
				pickDir()
			}

			/**
			 * 弹系统的「选择文件夹」——用 DSH 自己的那道门（`uiWorkspace.pickDirectory()`），
			 * 也就是开新会话选工作区时弹的同一个框。
			 *
			 * **不自己 spawn 进程**：试过，框开在别的窗口后面（Windows 只把前台激活权给前台进程，
			 * DSH 的原生选择框还得先合成一次 Alt 按键才抢得到）。
			 *
			 * 返回 `null` = 人点了取消，什么都不说；抛异常 = 这台 DSH 没有原生选择能力，
			 * 退回**内建目录浏览**（走 `uiWorkspace.listDirectory()`），两条路都断就还剩手填。
			 */
			async function pickDir() {
				if (pickerBusy) return
				// 这台 DSH 定的是 browse 后端时，`pickDirectory()` **必然**抛错（互斥：browse 只给 list）。
				// 别去撞那扇注定关着的门——直接开内建浏览，省一条没用的报错。
				if (pickerKind === 'browse') {
					if (hostList === null) {
						setBkNote({ kind: 'bad', text: '这台 DSH 选择的是「列目录」那套后端，但这个入口拿不到它——手填绝对路径吧。' })
						return
					}
					setBkNote(null)
					openBrowse()
					return
				}
				if (hostPick === null) {
					setBkNote({ kind: 'bad', text: '这个入口拿不到目录选择服务——用下面的目录浏览，或手填绝对路径。' })
					openBrowse()
					return
				}
				setPickerBusy(true)
				try {
					const picked = await hostPick()
					if (typeof picked === 'string' && picked.trim() !== '') {
						setDirValue(picked.trim())
						setBrowse(null)
						// **选 = 存**：选中即落笔（写进插件的 `store/backup.json`），
						// 不用再点第二颗按钮——用户对「选一次就记住」的预期就是这个。
						await commitDir(picked.trim())
					}
				} catch (failure) {
					// 打一份到控制台：这句是给「真弹不出来」时排查用的，界面上只留一句人话。
					try { console.warn('[dsh-tag-memory] 系统目录选择框没弹出来：', failure) } catch { /* 没控制台就算了 */ }
					// 兜底往下走：DSH 的目录选择有两套后端——native 给「弹系统框」，browse 只给
					// listDirectory。本机是 native（绑 127.0.0.1 + win32），但换台机器 / 换成远程访问
					// 就可能是 browse。所以这儿不猜，直接把内建浏览摊开，列不列得出来它自己会说。
					setBkNote({ kind: 'bad', text: `系统选择框没弹出来（${String((failure && failure.message) || failure)}）——改用下面的目录浏览，或手填绝对路径。` })
					openBrowse()
				} finally {
					setPickerBusy(false)
				}
			}

			/** 内建目录浏览：列一层，点进去，最后「就选这里」。 */
			async function openBrowse(path) {
				if (hostList === null) {
					// 不能一声不响地 return——点了没反应比报错更难受。
					setBrowse({ listing: null, error: '这个入口拿不到目录浏览服务（listDir）' })
					return
				}
				setBrowseBusy(true)
				try {
					const listing = await hostList(path)
					setBrowse({ listing, error: '' })
				} catch (failure) {
					setBrowse({ listing: null, error: String((failure && failure.message) || failure) })
				} finally {
					setBrowseBusy(false)
				}
			}

			/**
			 * 点「立即备份」。
			 * **没设地址不是弹提醒**——直接降级成「设置备份地址」那个状态（同一块面板）。
			 */
			async function doBackup() {
				if (bk === null || bk.dirSet !== true) { openDirForm(); return }
				setBkBusy('backup')
				setBkNote(null)
				try {
					const r = await postJSON(`${API}/backup`, {})
					if (r.ok) {
						const n = r.result?.entryCount ?? 0
						const extra = [
							r.result?.shifted > 0 ? '那个时间点已有内容不同的同名文件，这一份往后挪了几秒（备份从不覆盖已有内容）' : null,
							r.result?.rotated?.length ? `轮转清掉 ${r.result.rotated.length} 份旧档` : null,
						].filter(Boolean)
						setBkNote({ kind: 'ok', text: `备份好了：${n} 条 → ${r.result?.stamp ?? ''}${extra.length > 0 ? `（${extra.join('；')}）` : ''}` })
						if (r.status) setBk(r.status)
					} else {
						setBkNote({ kind: 'bad', text: `备份没成：${r.error ?? r.code}` })
						if (r.status) setBk(r.status)
					}
				} catch (failure) {
					setBkNote({ kind: 'bad', text: `备份没成：${String((failure && failure.message) || failure)}` })
				} finally {
					setBkBusy('')
				}
			}

			/**
			 * **把备份地址落进插件**——写 `store/backup.json` 的 `backupDir`。
			 *
			 * 这是地址的**唯一落笔点**：「选择文件夹…」和「就选这个目录」选中后自动走这里，
			 * 手填也在「保存这个地址」里走这里。**落笔之后刷新 / 重开界面都读得到**
			 * （面板顶上就摆着「当前地址」那一行），直到下一次重新选 / 重新保存为止。
			 *
			 * **只存地址，不顺手备份**——备份是另一件事，归标题行的「立即备份」管。
			 * 之前把两件事捆在一颗「存下并立刻备份」上，用户根本分不清到底存没存上：
			 * 选完就丢，正是那颗按钮的锅（选完不点它，地址就没落笔）。
			 */
			async function commitDir(value) {
				const dir = String(value ?? '').trim()
				if (dir === '') {
					// 空着点保存：把选择框弹出来让人选，别干等着。
					setBkNote({ kind: 'bad', text: '还没选目录呢——挑一个，或者把绝对路径粘进上面那格。' })
					return false
				}
				setBkBusy('dir')
				setBkNote(null)
				try {
					const r = await postJSON(`${API}/backup/dir`, { dir })
					if (!r.ok) {
						setBkNote({ kind: 'bad', text: r.error ?? '地址没存上' })
						return false
					}
					setDirValue(r.dir)
					if (r.status) setBk(r.status)
					setBkNote({
						kind: 'ok',
						text: `备份地址已保存：${r.dir}${r.created ? '（已新建目录）' : ''}。以后打开界面都是这儿；要立刻备份就点上面的「立即备份」。`,
					})
					return true
				} catch (failure) {
					setBkNote({ kind: 'bad', text: `地址没存上：${String((failure && failure.message) || failure)}` })
					return false
				} finally {
					setBkBusy('')
				}
			}

			/** 从某一份备份**整体替换**当前库；服务端会先强制留档再换。 */
			async function doRestore(stamp) {
				setBkBusy('restore')
				setBkNote(null)
				try {
					const r = await postJSON(`${API}/restore`, { stamp })
					if (r.ok) {
						setBkNote({ kind: 'ok', text: `已整体替换成 ${stamp} 那一版（${r.entryCount} 条）。替换前的那一版留档在 ${r.preBackup}。${r.schema === undefined || r.schema === null ? '' : `字典：${r.schema.note}`}` })
						setRestoreOpen(false)
						if (r.status) setBk(r.status)
						await reloadEntries()
					} else {
						setBkNote({ kind: 'bad', text: `恢复没成：${r.error ?? r.code}` })
					}
				} catch (failure) {
					setBkNote({ kind: 'bad', text: `恢复没成：${String((failure && failure.message) || failure)}` })
				} finally {
					setBkBusy('')
				}
			}

			/** 合并预演 / 真合并。预演不落笔。 */
			async function doMerge(apply) {
				const path = String(mergePath ?? '').trim()
				if (path === '') { setBkNote({ kind: 'bad', text: '先填另一台机器那份 memory.csv 的绝对路径' }); return }
				setBkBusy('merge')
				setBkNote(null)
				try {
					// `confirmOutside` 两次都带：预演与真合并走同一道闸，不能一次放一次拒。
					const r = await postJSON(`${API}/merge`, { path, apply: apply === true, confirmOutside: mergeConfirmedRef.current === true })
					if (!r.ok) {
						// 来源被闸门挡下时，把「怎么放行」直接说给用户，别只丢一个 code。
						const hint = r.code === 'SOURCE_OUTSIDE'
							? '　（不在备份目录里的话，勾上「我确认这是可信来源」再试）'
							: ''
						setBkNote({ kind: 'bad', text: `合并没成：${r.error ?? r.code}${hint}` })
						return
					}
					setMergeReport(r)
					if (r.dryRun === false) {
						const other = r.counts?.duplicateOtherProject ?? 0
						setBkNote({
							kind: 'ok',
							text: `合并完成：新增 ${r.appended?.length ?? 0} 条，跳过重复 ${r.counts?.duplicate ?? 0} 条`
								+ (other > 0 ? `（另有 ${other} 条仅内容相同、项目不同，已按新增并入）` : '')
								+ `；合并前那一版留档在 ${r.preBackup}。`,
						})
						if (r.status) setBk(r.status)
						await reloadEntries()
					}
				} catch (failure) {
					setBkNote({ kind: 'bad', text: `合并没成：${String((failure && failure.message) || failure)}` })
				} finally {
					setBkBusy('')
				}
			}

			/**
			 * 点某个维度值：选中 / 取消。同一维度多值 = 或，维度之间 = 与。
			 * 值一律存成数组，正好对上 core `matchKey` 的「多值」写法。
			 */
			function toggleDim(dim, value) {
				setCond((current) => {
					const next = { ...current }
					const list = next[dim] === undefined ? [] : asArr(next[dim])
					const after = list.includes(value) ? list.filter((v) => v !== value) : list.concat(value)
					if (after.length === 0) delete next[dim]
					else next[dim] = after
					return next
				})
			}

			/** 该维度值是否已选中（cond 里存的是数组）。 */
			function dimOn(dim, value) {
				return asArr(cond[dim] ?? []).includes(value)
			}

			/** 勾选 / 取消一条；存整行，方便后面复制导出。 */
			function toggleSelect(row) {
				setSelected((prev) => {
					const next = { ...prev }
					if (next[row.id] !== undefined) delete next[row.id]
					else next[row.id] = row
					return next
				})
			}

			/** 复制一段文本：先试剪贴板 API，失败退回临时 textarea + execCommand。 */
			async function copyText(text) {
				try {
					if (navigator.clipboard && navigator.clipboard.writeText) {
						await navigator.clipboard.writeText(text)
						return true
					}
				} catch { /* 落到兜底 */ }
				try {
					const area = document.createElement('textarea')
					area.value = text
					area.style.position = 'fixed'
					area.style.opacity = '0'
					document.body.appendChild(area)
					area.select()
					const done = document.execCommand('copy')
					area.remove()
					return done
				} catch { return false }
			}

			/** 选中条目 → Markdown 列表。 */
			function rowsToMarkdown(rows) {
				return rows
					.map((row) => {
						const meta = DETAIL_FIELDS
							.map((name) => (row[name] ? `${name}=${row[name]}` : null))
							.filter(Boolean)
							.join(' · ')
						return `- **${row.id}** ${row.内容 || ''}${meta ? `\n  - ${meta}` : ''}`
					})
					.join('\n')
			}

			/** 选中条目 → CSV（字段与设置页一致）。 */
			function rowsToCSV(rows) {
				const cols = ['id', '内容', ...DETAIL_FIELDS]
				const esc = (value) => {
					const s = String(value ?? '')
					return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
				}
				return [cols.join(','), ...rows.map((row) => cols.map((c) => esc(row[c])).join(','))].join('\n')
			}

			/** 把当前页的条目并入选择。 */
			function selectAllVisible() {
				toggleAllVisible(true)
			}

			/** 表头那个复选框：一次选中/取消本页全部。 */
			function toggleAllVisible(on) {
				setSelected((prev) => {
					const next = { ...prev }
					for (const row of items) {
						if (on) next[row.id] = row
						else delete next[row.id]
					}
					return next
				})
			}

			/** 复制选中条目为 Markdown。 */
			async function copySelected() {
				const rows = Object.values(selected)
				if (rows.length === 0) return setTip('先勾选条目，再复制。')
				const ok = await copyText(rowsToMarkdown(rows))
				setTip(ok ? `已复制 ${rows.length} 条为 Markdown` : '复制失败：浏览器未授予剪贴板权限')
			}

			/** 导出选中条目为 CSV 文件。 */
			function exportSelected() {
				const rows = Object.values(selected)
				if (rows.length === 0) return setTip('先勾选条目，再导出。')
				const blob = new Blob([rowsToCSV(rows)], { type: 'text/csv;charset=utf-8' })
				const url = URL.createObjectURL(blob)
				const link = document.createElement('a')
				link.href = url
				link.download = `tag-memory-${new Date().toISOString().slice(0, 10)}.csv`
				document.body.appendChild(link)
				link.click()
				link.remove()
				URL.revokeObjectURL(url)
				setTip(`已导出 ${rows.length} 条`)
			}

			/** 复制单条为 Markdown。 */
			async function copyOne(row) {
				const ok = await copyText(rowsToMarkdown([row]))
				setTip(ok ? `已复制 ${row.id}` : '复制失败：浏览器未授予剪贴板权限')
			}

			/** 当前条件的面包屑：每个标签可单独撤掉。 */
			function renderCrumbs() {
				const chips = []
				for (const [dim, values] of Object.entries(cond)) {
					for (const value of asArr(values)) {
						chips.push(
							React.createElement(
								'span',
								{ key: `${dim}=${value}`, className: 'tm-crumb' },
								`${dim}=${value}`,
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-crumb-x', title: '移除这个条件', onClick: () => toggleDim(dim, value) },
									'×',
								),
							),
						)
					}
				}
				if (includeArchived) {
					chips.push(
						React.createElement(
							'span',
							{ key: '含已归档', className: 'tm-crumb' },
							'含已归档',
							React.createElement(
								'button',
								{ type: 'button', className: 'tm-crumb-x', title: '移除这个条件', onClick: () => setIncludeArchived(false) },
								'×',
							),
						),
					)
				}
				return chips.length === 0 ? null : React.createElement('div', { className: 'tm-crumbs' }, chips)
			}

			/**
			 * 取代 / 归档：两个「改库语义」的动作，走同一个口。
			 *
			 * 界面**不能直接改 CSV**——那会绕开校验、判重、写锁和写前快照。
			 * 所以这里只做三件事：弹一句确认（改库是重操作，不能点错就生效）、
			 * 调 API、把结果（含快照名）说给用户听。
			 *
			 * `act` 是 'supersede' | 'archive' | 'unarchive'。
			 */
			async function markEntry(act, id, extra) {
				if (id === '') return
				const wording = act === 'supersede'
					? `把 ${id} 标记为「被取代」？\n\n旧条不会被删、也不会被改，会追加一条新的顶上；操作前会自动留一份快照。`
					: act === 'archive'
						? `把 ${id} 归档？\n\n归档后默认不再出现在列表与召回里（勾「含已归档」能查回来）；操作前会自动留一份快照。`
						: `把 ${id} 恢复成「生效」？`
				try { if (typeof window !== 'undefined' && !window.confirm(wording)) return } catch { /* 没有 confirm 就直接做 */ }
				setBusy(true)
				try {
					const url = act === 'supersede' ? `${API}/supersede` : `${API}/archive`
					const body = act === 'supersede'
						? { 目标id: id, ...(extra ?? {}) }
						: { 目标id: id, 状态: act === 'archive' ? '已归档' : '生效' }
					let r = await postJSON(url, body)
					// 被四判据拒了（NOT_CANDIDATE）→ 不是「失败」，是「这条不该归档」。
					// 给用户一次**显式**放行的机会：二次确认里把理由摆出来，用户点头才带 `强制复核` 重发。
					// 这样界面和智能体走的是同一套判据，区别只在「人能不能手动越过」。
					if (r.ok !== true && r.code === 'NOT_CANDIDATE') {
						const verdict = r.verdict ?? null
						const why = verdict !== null && typeof verdict.reason === 'string' ? verdict.reason : ''
						const ask = `这条现在**不满足归档判据**：\n\n${why || r.error}\n\n`
							+ '盘点出的候选是一份快照清单，执行时会重新校验——它可能刚被用过（强度回升），或者本来就不该归档。\n\n'
							+ '确实要归档吗？（强制复核）'
						let go = false
						try { go = typeof window !== 'undefined' ? window.confirm(ask) === true : false } catch { go = false }
						if (!go) { setTip(`已取消：${why || '不满足归档判据'}`); return }
						r = await postJSON(url, { ...body, 强制复核: true })
					}
					if (r.ok !== true) {
						setTip(`${act === 'supersede' ? '取代' : '归档'}没成功：${r.error ?? '未知原因'}`)
						return
					}
					if (act === 'supersede') setTip(`已取代 ${id} → ${r.id}（快照 ${r.snapshot ?? '—'}）`)
					else setTip(`${act === 'archive' ? '已归档' : '已恢复'} ${id}（快照 ${r.snapshot ?? '—'}）`)
					// 刷新列表：`reloadKey` +1 会让上面那个取数 effect 重跑（与筛选/排序同一套机制）。
					setReloadKey((k) => k + 1)
				} catch (e) {
					setTip(`请求失败：${String(e?.message ?? e)}`)
				} finally { setBusy(false) }
			}

			/** 翻转一个 {id: true} 形态的开关表（详情展开 / 正文展开）。 */
			function toggleFlag(setter, key) {
				setter((prev) => ({ ...prev, [key]: prev[key] !== true }))
			}

			/**
			 * ── V4-d 手动刷新 ────────────────────────────────
			 *
			 * 界面不是自动同步的：别处（智能体、另一个窗口、手改文件）写了库，
			 * 这里不点就一直是旧数据。所以给一颗「刷新」——重取概况与第一页。
			 *
			 * 为什么不是定时轮询：这套东西的写路径是「人点头才动」，轮询只是白耗请求；
			 * 而且轮询到的更新会**冲掉用户正在填的筛选**，那是更坏的体验。
			 * 打开时拉一次已有（挂载 effect），这里补的是「看着页面时的主动刷新」。
			 */
			async function refreshAll() {
				if (loading) return
				setReloadKey((k) => k + 1)
			}

			/**
			 * ── V4-e 批量归档 ────────────────────────────────
			 *
			 * 走现有 `POST /archive` **逐条**调，不新增批量 API（队长 2026-10-24 拍板）：
			 *   ① 每条归档前后端都自动拍快照，毫秒戳已就绪，连拍几十份不互相覆盖；
			 *   ② 逐条有天然的进度与失败隔离——第 3 条失败，前 2 条已经落盘且各有快照，
			 *      能准确报「成功 N / 失败 M」，用户知道到底动了哪几条；
			 *   ③ 批量 API 要处理「部分成功」的回滚语义（前 3 条成了、第 4 条失败要不要退回去），
			 *      那个语义比逐条复杂得多，异常路径上最容易出错。
			 *
			 * **二次确认必须带条数**：「将归档 N 条，确认？」。一次误操作 = N 条退场，
			 * 只说「确认归档？」等于没确认。这是阿验提的硬要求。
			 */
			async function archiveSelected() {
				/**
				 * 只认「还在待整理清单里」的勾选（P2 修复，阿栈 2026-10-25 交叉核对抓到的）。
				 *
				 * `pendingSel` 是 `{id:true}` 的累积表，条目从清单里消失（被单独归档、强度回升、
				 * 别处刷新）时它不会被自动清掉。于是：全勾 2 条 → 单独归档其中 1 条 → 按钮条数按
				 * 清单算成「归档所选（1）」，这里却按勾选表取到 2 个 id，确认框说「将归档 2 条」
				 * 并真去归档 2 条。二次确认的条数跟实际动作对不上，那条已消失的若强度回升就会被
				 * 顺带归档掉。所以**按钮条数与动作条数必须用同一个集合**：按 `overview.pendingDecay` 取交集。
				 */
				const live = new Set(
					(Array.isArray(overview?.pendingDecay) ? overview.pendingDecay : [])
						.map((it) => it?.id)
						.filter((id) => id !== undefined && id !== ''),
				)
				const picked = Object.keys(pendingSel)
				const ids = picked.filter((id) => live.has(id))
				// 顺手摘掉已不在清单里的残留勾选，免得下次又冒出来（也是「清空勾选」之外的自愈）。
				if (ids.length !== picked.length) {
					setPendingSel((prev) => {
						const next = {}
						for (const id of Object.keys(prev)) if (live.has(id)) next[id] = true
						return next
					})
				}
				if (ids.length === 0 || batch !== null) return
				// 硬要求：条数写进确认话里，不是「确认归档？」这种空话。
				const wording = `将归档 ${ids.length} 条，确认？\n\n${ids.join('、')}\n\n归档后它们默认不再出现在列表与召回里（勾「含已归档」能查回来）；每条归档前都会自动留一份快照。`
				try { if (typeof window !== 'undefined' && !window.confirm(wording)) return } catch { /* 没有 confirm 就直接做 */ }

				const total = ids.length
				const failed = []
				const failedIds = new Set()
				/** 被四判据拦下的（不是出错，是「不该归档」）——单独收，别混进失败。 */
				const rejected = []
				const rejectedIds = new Set()
				let okCount = 0
				setBatchNote(null)
				setBatchRejected(null)
				setBatch({ done: 0, total })
				for (let i = 0; i < ids.length; i++) {
					const id = ids[i]
					try {
						const r = await postJSON(`${API}/archive`, { 目标id: id, 状态: '已归档' })
						// `changed === false` 也算成功（本来就是已归档，没得改）——不能报成失败。
						if (r.ok === true) okCount++
						else if (r.code === 'NOT_CANDIDATE') {
							// 后端判据说这条不该归档（可能刚被强化过）。**不当失败报**：
							// 报成失败会让人以为系统坏了，其实规矩正常在工作。
							const why = r.verdict !== null && r.verdict !== undefined && typeof r.verdict.reason === 'string'
								? r.verdict.reason
								: (r.error ?? '')
							rejected.push({ id, why })
							rejectedIds.add(id)
						} else { failed.push(`${id}（${r.error ?? r.code ?? '未知原因'}）`); failedIds.add(id) }
					} catch (e) {
						failed.push(`${id}（${String(e?.message ?? e)}）`)
						failedIds.add(id)
					}
					setBatch({ done: i + 1, total })
				}

				setBatch(null)
				setBatchNote({ ok: okCount, failed })
				setBatchRejected(rejected.length > 0 ? rejected : null)
				// 成功的从勾选里摘掉；失败与被拒的留着，用户可以再点一次或单独强制。
				setPendingSel((prev) => {
					const next = { ...prev }
					for (const id of ids) if (!failedIds.has(id) && !rejectedIds.has(id)) delete next[id]
					return next
				})
				// 刷新列表与概况：归档的条目该从待整理区消失、列表里也不该再有。
				setReloadKey((k) => k + 1)
			}

			/**
			 * 把批量归档里被四判据拦下的那些**强制归档**（评审卡 kmvnul5t1k2p8 的批量侧）。
			 *
			 * 与单条的「强制复核」同一条路：二次确认把理由与条数都摆出来，用户点头才带
			 * `强制复核:true` 重发。**确认话里必须带条数**——批量强制一次退场 N 条，
			 * 只问「确认强制归档？」等于没确认（这是阿验对批量归档的同一套要求）。
			 */
			async function forceRejectedBatch() {
				const list = Array.isArray(batchRejected) ? batchRejected : []
				if (list.length === 0 || batch !== null) return
				const wording = `这 ${list.length} 条不满足归档判据，确认强制归档？\n\n`
					+ list.map((it) => `${it.id}：${it.why}`).join('\n')
					+ '\n\n它们可能刚被用过（强度回升），或者本来就不该归档。强制归档后同样会逐条留快照。'
				try { if (typeof window !== 'undefined' && !window.confirm(wording)) return } catch { /* 没有 confirm 就直接做 */ }

				const total = list.length
				const failed = []
				const failedIds = new Set()
				let okCount = 0
				setBatch({ done: 0, total })
				for (let i = 0; i < list.length; i++) {
					const id = list[i].id
					try {
						const r = await postJSON(`${API}/archive`, { 目标id: id, 状态: '已归档', 强制复核: true })
						if (r.ok === true) okCount++
						else { failed.push(`${id}（${r.error ?? r.code ?? '未知原因'}）`); failedIds.add(id) }
					} catch (e) {
						failed.push(`${id}（${String(e?.message ?? e)}）`)
						failedIds.add(id)
					}
					setBatch({ done: i + 1, total })
				}
				setBatch(null)
				setBatchNote({ ok: okCount, failed })
				setBatchRejected(null)
				setPendingSel((prev) => {
					const next = { ...prev }
					for (const it of list) if (!failedIds.has(it.id)) delete next[it.id]
					return next
				})
				setReloadKey((k) => k + 1)
			}

			/** 待整理区：全选 / 全不选（只作用于当前摆出来的那些）。 */
			function togglePendingAll(list, on) {
				setPendingSel((prev) => {
					const next = { ...prev }
					for (const it of list) {
						if (it?.id === undefined || it.id === '') continue
						if (on) next[it.id] = true
						else delete next[it.id]
					}
					return next
				})
			}

			/**
			 * 一条记忆的详情：全部非空字段（正文也在里面）。
			 * 卡片视图铺在卡片底部，表格视图铺在那一行下面——两处共用。
			 */
			function renderDetail(row) {
				/**
				 * 三态拆分（卡 kmvnul5yka32f）的两个列**空值也要摆**：
				 * 「已验证项目 = 空」是个有意义的答案（还没有项目验证过它），
				 * 按「只渲染非空项」的老口径会把它整个吞掉，用户看不到「这条没人验证过」。
				 * 其余字段仍按「非空才渲染」，免得详情里堆一片空行。
				 */
				const ALWAYS_SHOW = ['已验证项目', '使用次数']
				const detail = DETAIL_FIELDS
					.map((name) => [name, row[name]])
					.filter(([name, value]) => ALWAYS_SHOW.includes(name)
						|| (value !== undefined && value !== null && String(value) !== ''))
				return React.createElement(
					'div',
					{ className: 'tm-detail' },
					detail.length === 0
						? React.createElement('span', { className: 'tm-detail-k' }, '（无其它字段）')
						: detail.map(([name, value]) => {
								// 「距离」「依据」这两格直接决定**这条会不会进系统提示词全文**，
								// 光显示取值不够——用户得知道「深藏=只给索引」「外部=只给索引」。
								// 这段说明与后端 snapshotText 的分桶判据是同一套口径。
								const note = name === '距离'
									? (String(value) === '深藏'
										? '（深藏：正文不进上下文，只给一行索引，要用先 memory_recall 取）'
										: String(value) === '常驻' ? '（常驻：每轮进上下文全文）' : '（按需：命中才给全文）')
									: name === '依据'
										? (String(value) === '外部'
											? '（外部来源：只给带〔外部〕标记的索引，正文不进上下文）'
											: String(value) === '原话' ? '（用户原话）' : '')
										// ── 三态拆分（卡 kmvnul5yka32f）后的字段语义 ──
										// 这两列以前在界面上只是两个数字/一串项目名，没人知道它们怎么来的。
										// 现在按三态口径写清：**召回不算使用、更不算验证**。
										: name === '使用次数'
											? '（真正用于回答的次数；单纯被召回查出来不算）'
											: name === '已验证项目'
												? (String(value) === ''
													? '（还没有项目验证过它）'
													: '（用户确认过或跨项目实测成功的项目；被召回查出来不算验证）')
												: name === '强度'
													? '（衰减算出来的当前强度；召回不再自动加，只有真正用了才强化）'
													: ''
								return React.createElement(
									React.Fragment,
									{ key: name },
									React.createElement('span', { className: 'tm-detail-k' }, name),
									React.createElement(
										'span',
										{ className: 'tm-detail-v' },
										String(value),
										note !== '' ? React.createElement('span', { className: 'tm-detail-note' }, ' ' + note) : null,
									),
								)
							}),
				)
			}

			/** 表格单元格的文本：多行压成一行，过长截断（全文在 title 与「详情」里）。 */
			function cellText(value) {
				const text = String(value === undefined || value === null ? '' : value).replace(/\s+/g, ' ').trim()
				return text.length > CELL_CLIP ? text.slice(0, CELL_CLIP) + '…' : text
			}

			/** 一条记忆：正文过长可折叠，点「详情」就地展开全部非空字段。 */
			function renderItem(row, index) {
				const id = row.id || String(index)
				// 状态决定给哪几颗按钮（生效→取代/归档；已归档→恢复生效）
				const status = row.状态 || ''
				const content = row.内容 || '（无内容）'
				const isLong = content.length > CONTENT_CLIP
				const showFull = fullText[id] === true
				const shown = isLong && !showFull ? content.slice(0, CONTENT_CLIP) + '…' : content

				const tags = []
				// 外部来源先标（评审卡 kmvnul5xkdg1l）：它是「这条不是用户说的」的第一信号，
				// 排在所有标签最前面，扫一眼就知道该不该照做。
				if (row.依据 === '外部') {
					tags.push(React.createElement('span', { key: '外部', className: 'tm-mtag tm-mtag-ext', title: '依据=外部：从别处抄来的（文档/项目/他人经验），不是用户原话，采信前先核对' }, '外部来源'))
				}
				for (const name of ['类型', '深度', '稳定性', '距离', '角色', '项目', '状态']) {
					if (row[name]) tags.push(React.createElement('span', { key: name, className: 'tm-mtag' }, `${name} `, React.createElement('b', null, row[name])))
				}
				if (row.时间) tags.push(React.createElement('span', { key: '时间', className: 'tm-mtag' }, row.时间))

				const open = expanded[id] === true

				return React.createElement(
					'div',
					{ key: id, className: 'tm-item' },
					React.createElement(
						'div',
						{ className: 'tm-item-h' },
						React.createElement('input', {
							type: 'checkbox',
							className: 'tm-check',
							checked: selected[id] !== undefined,
							onChange: () => toggleSelect(row),
						}),
						React.createElement('span', { className: 'tm-id' }, row.id),
						React.createElement(
							'span',
							{ className: 'tm-content' },
							shown,
							isLong
								? React.createElement(
										'button',
										{ type: 'button', className: 'tm-link', onClick: () => toggleFlag(setFullText, id) },
										showFull ? '收起' : '展开',
									)
								: null,
						),
					),
					tags.length > 0 ? React.createElement('div', { className: 'tm-meta' }, tags) : null,
					React.createElement(
						'div',
						{ className: 'tm-actions' },
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-link', onClick: () => toggleFlag(setExpanded, id) },
							open ? '收起详情' : '详情',
						),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-link', onClick: () => copyOne(row) },
							'复制',
						),
						// 取代 / 归档：改库语义的动作，走 API（不直接碰 CSV）。
						// 只在**生效**的条目上给按钮——已退场的条目再点「取代」只会拿到一句拒绝。
						status === '生效'
							? React.createElement(
								'button',
								{ type: 'button', className: 'tm-link', onClick: () => markEntry('supersede', row.id), disabled: busy },
								'标记被取代',
							)
							: null,
						status === '已归档'
							? React.createElement(
								'button',
								{ type: 'button', className: 'tm-link', onClick: () => markEntry('unarchive', row.id), disabled: busy },
								'恢复生效',
							)
							: React.createElement(
								'button',
								{ type: 'button', className: 'tm-link', onClick: () => markEntry('archive', row.id), disabled: busy },
								'归档',
							),
					),
					open ? renderDetail(row) : null,
				)
			}

			/**
			 * 表格视图：库本来就是 CSV，一行一条、一列一个字段，比卡片省地方得多。
			 * 表头 + 首列（勾选）常驻，横向可滚；行内「详情」展开这一行的全部字段。
			 */
			/**
			 * ── 列计划（V4-f）──────────────────────────────────
			 *
			 * 一处算清「这库有哪些列、该显示哪些」，表格与列设置共用**同一份**判据。
			 * 两份实现迟早分叉（改一处忘另一处），这库已经在「盘点清单」上踩过这个坑。
			 *
			 * - `all`：库自己表头里的列（库长什么样就是什么样）；overview 没回来时用兜底表头。
			 * - `visible`：真正铺到表格里的列。用户在列设置里勾过就听用户的（还要过一遍
			 *   `all`，勾了但本库没这列的自动跳过）；没勾过就用 `DEFAULT_COLUMNS`。
			 * - `missingNew`：0.3.0 的 4 个新列里，本库表头还没有的那些（老库 17 列）。
			 *   它们在列设置里照样列出来，但标「未落列」且不可勾——勾了也不会有值。
			 */
			function columnPlan() {
				const all = overview !== null && Array.isArray(overview.header) && overview.header.length > 0
					? overview.header.map(String)
					: FALLBACK_HEADER
				const chosen = Array.isArray(columnsPicked) && columnsPicked.length > 0
					? columnsPicked.filter((name) => all.includes(name))
					: DEFAULT_COLUMNS.filter((name) => all.includes(name))
				const visible = chosen.length > 0 ? chosen : all.slice(0, 12)
				// 本库表头里还没有的新列：列设置里照样列出来，但标成「未落列」且不可勾。
				const missingNew = NEW_COLUMNS.filter((name) => !all.includes(name))
				return { all, visible, available: all, missingNew }
			}

			/**
			 * 列设置面板（V4-f）：把库里的列照实摊出来，勾哪个显示哪个。
			 *
			 * 摆在「记忆条目」卡里、表格上面，默认收起。**它是设置，不是内容**——
			 * 按主位通则不占正文，要改列的人才点开。
			 * 勾选落 localStorage（`columns`），下次进来还在。
			 */
			function renderColumnPicker() {
				const plan = columnPlan()
				const on = new Set(plan.visible)
				return React.createElement(
					'div',
					{ className: 'tm-colpick' },
					React.createElement(
						'div',
						{ className: 'tm-colpick-h' },
						React.createElement('span', { className: 'tm-note' }, '勾选要在表格里显示的列（只影响表格视图，选择会记住）'),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', onClick: () => setColumnsPicked(null) },
							'恢复默认',
						),
					),
					React.createElement(
						'div',
						{ className: 'tm-colpick-list' },
						plan.all.map((name) => {
							const isNew = NEW_COLUMNS.includes(name)
							return React.createElement(
								'label',
								{ key: name, className: 'tm-colpick-item', 'data-new': isNew ? 'true' : undefined },
								React.createElement('input', {
									type: 'checkbox',
									className: 'tm-check',
									checked: on.has(name),
									onChange: () => {
										const next = plan.visible.includes(name)
											? plan.visible.filter((c) => c !== name)
											: plan.all.filter((c) => c === name || plan.visible.includes(c))
										// 一列都不剩就退回默认，别把表清成空壳。
										setColumnsPicked(next.length > 0 ? next : null)
									},
								}),
								React.createElement('span', null, name),
								isNew ? React.createElement('span', { className: 'tm-mtag' }, '0.3.0 新列') : null,
							)
						}),
						plan.missingNew.map((name) => React.createElement(
							'label',
							{ key: `missing-${name}`, className: 'tm-colpick-item', 'data-off': 'true', title: '本库表头还没有这一列（表头迁移后自动出现）' },
							React.createElement('input', { type: 'checkbox', className: 'tm-check', checked: false, disabled: true, onChange: () => {} }),
							React.createElement('span', null, name),
							React.createElement('span', { className: 'tm-mtag' }, '未落列'),
						)),
					),
				)
			}

			function renderTable() {
				const ids = items.map((row) => row.id)
				const allOn = ids.length > 0 && ids.every((id) => selected[id] !== undefined)

				/**
				 * 列名与列序都照库自己的表头（`overview.header`），只是挑了其中一拨显示。
				 * 库改了列名/挪了列序，表格跟着走；表头里没有的列（老库）自动跳过。
				 * 个别维度名与列名不同（`成熟度` 列在 schema 里叫 `深度`），所以行对象里
				 * 的键要经维度映射——表头显示列名，筛选下拉显示维度名。
				 */
				const picked = columnPlan().visible
				const columns = picked.map((name) => {
					const dim = dims.find((d) => d.column === name)
					return {
						name,
						key: dim === undefined ? name : dim.name,
						hint: dim === undefined ? '' : `（维度「${dim.name}」）`,
						kind: COLUMN_KIND[name] ?? '',
					}
				})

				const head = React.createElement(
					'thead',
					null,
					React.createElement(
						'tr',
						null,
						React.createElement(
							'th',
							{ className: 'tm-col-check' },
							React.createElement('input', {
								type: 'checkbox',
								className: 'tm-check',
								checked: allOn,
								title: allOn ? '取消全选本页' : '全选本页',
								onChange: () => toggleAllVisible(!allOn),
							}),
						),
						columns.map((col) => React.createElement('th', { key: col.name, title: col.hint || undefined }, col.name)),
						React.createElement('th', null, '操作'),
					),
				)

				const body = React.createElement(
					'tbody',
					null,
					items.flatMap((row, index) => {
						const id = row.id || String(index)
						const open = expanded[id] === true
						const main = React.createElement(
							'tr',
							{ key: id },
							React.createElement(
								'td',
								{ className: 'tm-col-check' },
								React.createElement('input', {
									type: 'checkbox',
									className: 'tm-check',
									checked: selected[id] !== undefined,
									onChange: () => toggleSelect(row),
								}),
							),
							columns.map((col) =>
								React.createElement(
									'td',
									{ key: col.name, className: col.kind === 'mono' ? 'tm-td-id' : undefined },
									React.createElement(
										'span',
										{
											className: col.kind === 'wide' ? 'tm-clip tm-clip-wide' : 'tm-clip',
											title: String(row[col.key] === undefined || row[col.key] === null ? '' : row[col.key]),
										},
										cellText(row[col.key]) || '—',
									),
									// 外部来源角标（评审卡 kmvnul5xkdg1l）：表格里「依据」列常被
									// 收进详情看不见，角标挂在 id 格里，扫一眼就知道这条不是用户说的。
									col.name === 'id' && row.依据 === '外部'
										? React.createElement('span', { className: 'tm-mtag tm-mtag-ext', title: '依据=外部：从别处抄来的，不是用户原话，采信前先核对' }, '外部')
										: null,
								),
							),
							React.createElement(
								'td',
								{ className: 'tm-td-ops' },
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-link', onClick: () => toggleFlag(setExpanded, id) },
									open ? '收起' : '详情',
								),
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-link', onClick: () => copyOne(row) },
									'复制',
								),
								// 取代 / 归档（与卡片视图同一套：只对生效条目给「取代」）
								(row.状态 || '') === '生效'
									? React.createElement(
										'button',
										{ type: 'button', className: 'tm-link', onClick: () => markEntry('supersede', id), disabled: busy },
										'标记被取代',
									)
									: null,
								(row.状态 || '') === '已归档'
									? React.createElement(
										'button',
										{ type: 'button', className: 'tm-link', onClick: () => markEntry('unarchive', id), disabled: busy },
										'恢复生效',
									)
									: React.createElement(
										'button',
										{ type: 'button', className: 'tm-link', onClick: () => markEntry('archive', id), disabled: busy },
										'归档',
									),
							),
						)
						if (!open) return [main]
						return [
							main,
							React.createElement(
								'tr',
								{ key: `${id}-detail`, className: 'tm-tr-detail' },
								React.createElement('td', { colSpan: columns.length + 2 }, renderDetail(row)),
							),
						]
					}),
				)

				return React.createElement(
					'div',
					{ className: 'tm-tablewrap' },
					React.createElement('table', { className: 'tm-table' }, head, body),
				)
			}

			// ── 备份相关的几块 ─────────────────────────────

			/** 标题右边那一排按钮。备份是「用户要点的」，所以放在主位、跟标题同一行。 */
			function renderBarButtons() {
				const set = bk !== null && bk.dirSet === true
				return React.createElement(
					'div',
					{ className: 'tm-barbtns' },
					React.createElement(
						'button',
						{ type: 'button', className: 'tm-btn', disabled: bkBusy !== '', onClick: doBackup },
						bkBusy === 'backup' ? '备份中…' : '立即备份',
					),
					React.createElement(
						'button',
						{
							type: 'button',
							className: 'tm-btn',
							disabled: bkBusy !== '' || !set,
							title: set ? '拿某一份备份把当前记忆库整体换掉' : '先设置备份地址',
							onClick: () => { setRestoreOpen((v) => !v); setMergeOpen(false); setBkNote(null) },
						},
						'恢复…',
					),
					React.createElement(
						'button',
						{
							type: 'button',
							className: 'tm-btn',
							disabled: bkBusy !== '',
							title: '把另一台机器的 memory.csv 并进来（只追加，不删不改）',
							onClick: () => { setMergeOpen((v) => !v); setRestoreOpen(false); setBkNote(null) },
						},
						'合并…',
					),
					React.createElement(
						'button',
						{ type: 'button', className: 'tm-btn tm-primary', disabled: bkBusy !== '', onClick: openDirForm },
						'设置备份地址…',
					),
				)
			}

			/** 标题下面那行备份现状：地址 / 上次 / 条数差 / 份数。 */
			function renderBackupLine() {
				if (bk === null) return React.createElement('div', { className: 'tm-bkline' }, '备份：读取中…')
				if (bk.available === false) {
					return React.createElement(
						'div',
						{ className: 'tm-bkline' },
						React.createElement('span', { className: 'tm-bad' }, `备份功能不可用：${bk.error ?? ''}`),
					)
				}
				const parts = []
				parts.push(React.createElement('span', { key: 'dir' },
					React.createElement('span', null, '备份地址：'),
					bk.dirSet
						? React.createElement('b', null, bk.dir)
						: React.createElement('span', { className: 'tm-warn' }, '未设置'),
				))
				parts.push(React.createElement('span', { key: 'when' },
					React.createElement('span', null, '上次备份：'),
					bk.lastBackupAt === ''
						? React.createElement('span', { className: 'tm-warn' }, '从未')
						: React.createElement('b', null, shortTime(bk.lastBackupAt)),
				))
				if (bk.dirSet) {
					const delta = bk.delta
					parts.push(React.createElement('span', { key: 'count' },
						`库里 ${bk.currentCount} 条`,
						typeof delta === 'number' && delta !== 0 ? `（比上次 ${delta > 0 ? '+' : ''}${delta}）` : '',
					))
					parts.push(React.createElement('span', { key: 'copies' },
						`备份 ${bk.copies} 份${bk.totalBytes > 0 ? ` / ${humanBytes(bk.totalBytes)}` : ''}`,
					))
					if (bk.freeBytes !== null && bk.freeBytes !== undefined) {
						parts.push(React.createElement('span', { key: 'free' }, `盘上余 ${humanBytes(bk.freeBytes)}`))
					}
					if (bk.dirError !== '') parts.push(React.createElement('span', { key: 'err', className: 'tm-warn' }, bk.dirError))
					if (bk.due) parts.push(React.createElement('span', { key: 'due', className: 'tm-warn' }, `该备份了：${bk.dueReason.join('；')}`))
				}
				return React.createElement('div', { className: 'tm-bkline' }, parts)
			}

			/**
			 * 设置备份地址。**没有默认目录**——地址由人给。
			 * 点「立即备份」而地址为空时，打开的就是这一块（降级），而不是弹一句提醒。
			 */
			function renderDirPane() {
				if (!dirOpen) return null
				return React.createElement(
					'div',
					{ className: 'tm-pane' },
					React.createElement(
						'div',
						{ className: 'tm-pane-h' },
						React.createElement('h2', { className: 'tm-pane-t' }, '设置备份地址'),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', onClick: () => setDirOpen(false) },
							'收起',
						),
					),
					// 一打开就摆出**库里真正存着的那个地址**——不然空格子让人以为没存上。
					React.createElement(
						'div',
						{ className: 'tm-field', style: { marginBottom: '8px' } },
						React.createElement('span', null, '当前地址：'),
						typeof bk?.dir === 'string' && bk.dir.trim() !== ''
							? React.createElement('b', null, bk.dir)
							: React.createElement('span', { className: 'tm-warn' }, '还没设置'),
					),
					React.createElement(
						'div',
						{ className: 'tm-note', style: { marginBottom: '8px' } },
						'**选一次就记住**：点「浏览」（或下面的目录浏览）选中即存，以后打开界面都是它，直到你重新选。也可以手填绝对路径，按右边「保存这个地址」。备份会往这个目录里写 `memory-<日期>-<时分秒>.csv` 之类的一整套文件；目录不存在会自动新建。别两个引擎共用一个目录——备份本身从不覆盖（戳撞上会往后挪），但**轮转只留最近几份**，共用会让两边互相清掉旧档。',
					),
					// 注意：这里是 div 不是 form。**form 的默认动作是提交导航，会把整页刷掉**——
					// 之前用 form + type=submit，空输入一点就整页重载，等于白点。
					React.createElement(
						'div',
						{ className: 'tm-field' },
						React.createElement('input', {
							className: 'tm-input',
							type: 'text',
							ref: dirRef,
							placeholder: '绝对路径，例如 D:\\backup\\记忆库',
							value: dirValue,
							onChange: (event) => setDirValue(event.target.value),
							onKeyDown: (event) => {
								if (event.key === 'Enter') { event.preventDefault(); commitDir(dirValue) }
							},
						}),
						// 两条路都没接上时就别摆这颗按钮了——点了没反应比没有更难受。
						// 输入框还在，手填绝对路径照样能用。
						(hostPick === null && hostList === null)
							? null
							: React.createElement(
								'button',
								{
									type: 'button',
									className: 'tm-btn',
									disabled: pickerBusy || bkBusy !== '',
									onClick: pickDir,
									// 按钮叫什么、点了会发生什么，取决于**这台 DSH 定的是哪套后端**（互斥）：
									// browse 后端点它开的是内建目录浏览，不是系统框。
									title: pickerKind === 'browse'
										? '这台 DSH 用的是「列目录」后端——点开会在这儿列出目录，点进去再「就选这个目录」'
										: '弹系统的「选择文件夹」框（DSH 自己的 uiWorkspace.pickDirectory）',
								},
								pickerBusy ? '选择框开着…' : (pickerKind === 'browse' ? '浏览目录…' : '浏览…'),
							),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn tm-primary', disabled: bkBusy !== '', onClick: () => commitDir(dirValue) },
							bkBusy === 'dir' ? '保存中…' : '保存这个地址',
						),
					),
					renderBrowse(),
				)
			}

			/**
			 * 内建目录浏览——系统选择框弹不出来时的兜底（也是唯一的「到处都能用」的那条路）。
			 * 数据是宿主 `uiWorkspace.listDirectory()` 给的：当前层 + 面包屑，客户端不自己拼路径。
			 */
			function renderBrowse() {
				if (browse === null) return null
				if (browse.error !== '') {
					return React.createElement('div', { className: 'tm-note tm-warn', style: { marginTop: '8px' } }, `列不出目录：${browse.error}`)
				}
				const l = browse.listing
				const crumbs = Array.isArray(l?.crumbs) ? l.crumbs : []
				const entries = Array.isArray(l?.entries) ? l.entries : []
				return React.createElement(
					'div',
					{ className: 'tm-browse' },
					React.createElement(
						'div',
						{ className: 'tm-crumbs' },
						crumbs.map((c, i) =>
							React.createElement(
								'span',
								{ key: c.path, className: 'tm-crumb-wrap' },
								i > 0 ? React.createElement('span', { className: 'tm-crumb-sep' }, '/') : null,
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-crumb', disabled: browseBusy, onClick: () => openBrowse(c.path) },
									c.name,
								),
							),
						),
					),
					React.createElement(
						'div',
						{ className: 'tm-browse-list' },
						browseBusy
							? React.createElement('div', { className: 'tm-note' }, '读着…')
							: entries.length === 0
								? React.createElement('div', { className: 'tm-note' }, '这一层没有子目录。')
								: entries.map((e) =>
										React.createElement(
											'button',
											{ key: e.path, type: 'button', className: 'tm-dir', onClick: () => openBrowse(e.path) },
											`📁 ${e.name}`,
										),
									),
					),
					React.createElement(
						'div',
						{ className: 'tm-field', style: { marginTop: '8px' } },
						React.createElement(
							'button',
							{
								type: 'button',
								className: 'tm-btn tm-primary',
								disabled: browseBusy || !l?.path,
								onClick: () => { const p = String(l.path); setDirValue(p); setBrowse(null); commitDir(p) },
							},
							'就选这个目录',
						),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', disabled: browseBusy, onClick: () => openBrowse(l?.path) },
							'刷新',
						),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', disabled: browseBusy, onClick: () => setBrowse(null) },
							'收起浏览',
						),
					),
				)
			}

			/** 恢复：列出手上有的备份，点一下就把整库换成那一版。 */
			function renderRestorePane() {
				if (!restoreOpen) return null
				const recent = bk !== null && Array.isArray(bk.recent) ? bk.recent : []
				return React.createElement(
					'div',
					{ className: 'tm-pane' },
					React.createElement(
						'div',
						{ className: 'tm-pane-h' },
						React.createElement('h2', { className: 'tm-pane-t' }, '恢复（整体替换）'),
						React.createElement('button', { type: 'button', className: 'tm-btn', onClick: () => setRestoreOpen(false) }, '收起'),
					),
					React.createElement(
						'div',
						{ className: 'tm-note', style: { marginBottom: '8px' } },
						'恢复是**整体替换**：把当前记忆库换成选中的那一版，不是往上面补。所以点下去之前，服务端会先把现在这一版自动留档一份，换完还要再核对一遍记录数；对不上就报错并告诉你用哪一份回退。',
					),
					recent.length === 0
						? React.createElement('div', { className: 'tm-note' }, '备份目录里还没有可恢复的备份。')
						: recent.map((row) => React.createElement(
								'div',
								{ key: row.stamp, className: 'tm-bkrow' },
								React.createElement('span', { className: 'tm-mono' }, row.stamp),
								React.createElement('span', null, row.at !== '' ? shortTime(row.at) : '—'),
								React.createElement('span', null, row.count !== null ? `${row.count} 条` : ''),
								row.label !== '' ? React.createElement('span', { className: 'tm-note' }, row.label) : null,
								// 「无字典」只标**加字典之前**的老备份（`hasSchema === false`）；旧宿主不报这一项，
								// 那就是 `undefined`，什么都不标——不拿新规矩去猜旧数据。
								React.createElement('span', { className: 'tm-tag' },
									`${row.complete ? humanBytes(row.bytes) : '不完整'}${row.hasSchema === false ? ' · 无字典' : ''}`),
								React.createElement(
									'button',
									{
										type: 'button',
										className: 'tm-btn',
										disabled: bkBusy !== '' || !row.complete,
										onClick: () => doRestore(row.stamp),
									},
									bkBusy === 'restore' ? '恢复中…' : '用这一份',
								),
							)),
				)
			}

			/** 合并：先预演出报告，人看过再点「确认合并」。 */
			function renderMergePane() {
				if (!mergeOpen) return null
				const r = mergeReport
				return React.createElement(
					'div',
					{ className: 'tm-pane' },
					React.createElement(
						'div',
						{ className: 'tm-pane-h' },
						React.createElement('h2', { className: 'tm-pane-t' }, '合并另一份记忆库'),
						React.createElement('button', { type: 'button', className: 'tm-btn', onClick: () => { setMergeOpen(false); setMergeReport(null) } }, '收起'),
					),
					React.createElement(
						'div',
						{ className: 'tm-note', style: { marginBottom: '8px' } },
						'填另一台机器／另一份库里 `store/memory.csv` 的绝对路径。规矩是：**先留档、只追加、不重写、不删任何条目**；判重看「内容 + 项目 + 类型」——三者都同才算重复跳过，仅内容相同但项目不同会**按新增并入**。来源里不合规的（内容空、必填缺项）**预演时就会挑出来**，不会等真合并才一条条失败。',
					),
					React.createElement(
						'div',
						{ className: 'tm-field' },
						React.createElement('input', {
							className: 'tm-input',
							type: 'text',
							placeholder: '例如 D:\\other\\tag-memory\\store\\memory.csv',
							value: mergePath,
							onChange: (event) => setMergePath(event.target.value),
						}),
					),
					// R-7 的准入闸：路径不在备份目录/库目录之下时，必须显式确认。
					// 这条不是「多此一举」——来源 CSV 会被注入记忆、再进每轮系统提示词，
					// 任意路径都能合等于给记忆投毒开了门。
					React.createElement(
						'label',
						{ className: 'tm-note', style: { display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px', cursor: 'pointer' } },
						React.createElement('input', {
							type: 'checkbox',
							defaultChecked: false,
							onChange: (event) => { mergeConfirmedRef.current = event.target.checked },
						}),
						'我确认这是可信来源（路径不在备份目录里时，勾上才会放行）',
					),
					React.createElement(
						'div',
						{ className: 'tm-field' },
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', disabled: bkBusy !== '', onClick: () => doMerge(false) },
							bkBusy === 'merge' ? '读着…' : '先预演（不落笔）',
						),
						r !== null && r.dryRun !== false
							? React.createElement(
									'button',
									{ type: 'button', className: 'tm-btn tm-primary', disabled: bkBusy !== '' || (r.counts?.new ?? 0) === 0, onClick: () => doMerge(true) },
									`确认合并（新增 ${r.counts?.new ?? 0} 条）`,
								)
							: null,
					),
					r === null ? null : renderMergeReport(r),
				)
			}

			/** §6.4 要的那份交代：新增 / 跳过 / 改号 / 标签差异 / 冲突。 */
			function renderMergeReport(r) {
				const rows = [
					['来源', r.source],
					['带上来的条目', `${r.incomingTotal} 条（本地 ${r.localTotal} 条）`],
					['新增', `${r.counts.new} 条`],
					['重复跳过（内容+项目+类型都相同）', `${r.counts.duplicate} 条`],
					['仅内容相同、项目不同（按新增并入）', `${r.counts.duplicateOtherProject ?? 0} 条`],
					['id 撞号改新号', `${r.counts.idCollision} 条`],
					['内容空 / 必填缺项（加不进去）', `${r.counts.invalid} 条`],
					['同一条但标签不一样', `${r.counts.tagDiff} 条`],
				]
				return React.createElement(
					'div',
					{ style: { marginTop: '10px' } },
					r.headerMismatch
						? React.createElement('div', { className: 'tm-note tm-warn' }, `表头和本地不完全一样${r.missingColumns.length > 0 ? `；本地有而来源没有的列：${r.missingColumns.join('、')}（按空处理）` : ''}`)
						: React.createElement('div', { className: 'tm-note tm-ok' }, '表头和本地一致。'),
					React.createElement(
						'div',
						{ className: 'tm-kv', style: { marginTop: '8px' } },
						rows.map(([k, v]) => React.createElement(
							'div',
							{ key: k, className: 'tm-kv-row' },
							React.createElement('div', { className: 'tm-kv-k' }, k),
							React.createElement('div', { className: 'tm-kv-v' }, v),
						)),
					),
					r.newList.length === 0 ? null : React.createElement(
						'div',
						{ style: { marginTop: '10px' } },
						React.createElement('div', { className: 'tm-note' }, `要新增的（最多列 50）：`),
						r.newList.map((it) => React.createElement(
							'div',
							{ key: `${it.id}-${it.preview}`, className: 'tm-bkrow' },
							React.createElement('span', { className: 'tm-mono' }, it.时间 || it.id),
							React.createElement('span', null, it.preview),
							it.why !== '' ? React.createElement('span', { className: 'tm-tag' }, it.why) : null,
						)),
					),
					Array.isArray(r.invalidList) && r.invalidList.length > 0 ? React.createElement(
						'div',
						{ style: { marginTop: '10px' } },
						React.createElement('div', { className: 'tm-note tm-warn' }, `这几条**没进来**（来源里就不合规，本地一个字节没动）：`),
						r.invalidList.map((it, i) => React.createElement(
							'div',
							{ key: `bad-${i}-${it.id}`, className: 'tm-bkrow' },
							React.createElement('span', { className: 'tm-mono' }, it.id || '（无 id）'),
							React.createElement('span', null, it.preview || ''),
							React.createElement('span', { className: 'tm-tag' }, it.why),
						)),
					) : null,
					r.tagDiffs.length === 0 ? null : React.createElement(
						'div',
						{ style: { marginTop: '10px' } },
						React.createElement('div', { className: 'tm-note' }, '内容一样但标签不一样（**不删**，按标签区分；想改就手改库）：'),
						r.tagDiffs.map((it) => React.createElement(
							'div',
							{ key: it.id, className: 'tm-bkrow' },
							React.createElement('span', { className: 'tm-mono' }, it.id),
							React.createElement('span', null, it.preview),
							React.createElement('span', { className: 'tm-tag' }, it.diffs.map((d) => `${d.field}: ${d.local || '空'}→${d.incoming || '空'}`).join(' · ')),
						)),
					),
					Array.isArray(r.appended) && r.appended.length > 0
						? React.createElement('div', { className: 'tm-note tm-ok', style: { marginTop: '8px' } }, `已追加 ${r.appended.length} 条：${r.appended.map((a) => a.id).join('、')}`)
						: null,
					Array.isArray(r.failed) && r.failed.length > 0
						? React.createElement('div', { className: 'tm-note tm-bad', style: { marginTop: '8px' } }, `有 ${r.failed.length} 条没进来：${r.failed.map((f) => `${f.preview}（${f.why}）`).join('；')}`)
						: null,
				)
			}

			/**
			 * 待整理 / 待晋升（V3 建区，V4-e/f 补批量与预览）。
			 *
			 * 两块都是**候选清单**：强度低的进待整理（不自动归档）、项目数够的进待晋升
			 * （不自动晋升）。所有动作都要人点一下——错归档/错晋升正是这套设计要防的失败。
			 *
			 * 数据来自 `/overview` 的 `pendingDecay` / `pendingPromote`（服务端现算，不落盘）。
			 * 字段是 `{ id, 内容, 项目, 时间, 强度, 深度, 距离, 最后强化 }`（晋升项另有
			 * `已验证项目`、`项目数`）——**预览取 `内容`**，别写成 `preview`（那是合并报告
			 * 的字段名，两个清单里没有；V3 修 P1 时清单才补上 `id` 与 `内容`）。
			 */
			function renderPending() {
				const decay = Array.isArray(overview?.pendingDecay) ? overview.pendingDecay : []
				const promote = Array.isArray(overview?.pendingPromote) ? overview.pendingPromote : []
				if (decay.length === 0 && promote.length === 0) return null
				const selCount = decay.filter((it) => pendingSel[it.id] === true).length
				const allOn = decay.length > 0 && selCount === decay.length
				const running = batch !== null
				return React.createElement(
					'div',
					{ className: 'tm-card', style: { marginTop: '10px' } },
					React.createElement('h2', { className: 'tm-pane-t', style: { marginTop: 0 } }, '待整理'),
					// ── V4-e 批量条：全选 / 归档所选 / 进度 ──
					decay.length === 0 ? null : React.createElement(
						'div',
						{ className: 'tm-batchbar' },
						React.createElement(
							'label',
							{ className: 'tm-colpick-item' },
							React.createElement('input', {
								type: 'checkbox',
								className: 'tm-check',
								checked: allOn,
								disabled: running,
								onChange: () => togglePendingAll(decay, !allOn),
							}),
							`全选（${decay.length} 条）`,
						),
						React.createElement(
							'button',
							{
								type: 'button',
								className: 'tm-btn',
								disabled: running || selCount === 0,
								title: selCount === 0 ? '先勾几条' : `将归档 ${selCount} 条（会再确认一次）`,
								onClick: archiveSelected,
							},
							running ? '归档中…' : `归档所选（${selCount}）`,
						),
						selCount > 0 && !running
							? React.createElement('button', { type: 'button', className: 'tm-btn', onClick: () => setPendingSel({}) }, '清空勾选')
							: null,
						// 进度：跑到第几条说清楚，别让用户对着不动的按钮猜。
						running
							? React.createElement('span', { className: 'tm-count' }, `归档中 ${batch.done}/${batch.total}…`)
							: React.createElement('span', { className: 'tm-count' }, selCount === 0 ? '勾选后可以一次归档多条' : `已选 ${selCount} 条`),
					),
					// 批量归档收尾：成功 N / 失败 M，失败的逐条摆出来（谁、为什么）。
					batchNote !== null
						? React.createElement(
								'div',
								{ className: `tm-note ${batchNote.failed.length > 0 ? 'tm-warn' : 'tm-ok'}`, style: { marginBottom: '6px' } },
								`批量归档完成：成功 ${batchNote.ok} 条${batchNote.failed.length > 0 ? `，失败 ${batchNote.failed.length} 条（${batchNote.failed.join('；')}）` : ''}。`,
							)
						: null,
					// 被四判据拦下的：不是失败，是「按规矩不该归档」。单独一块，理由逐条摆，
					// 想越过得自己点「强制归档这 N 条」再确认一次（卡 kmvnul5t1k2p8）。
					batchRejected !== null && batchRejected.length > 0
						? React.createElement(
								'div',
								{ className: 'tm-note tm-warn', style: { marginBottom: '6px' } },
								`有 ${batchRejected.length} 条不满足归档判据，没有归档（不是出错，是它们不该归档）：`,
								React.createElement('br'),
								batchRejected.map((it) => `${it.id}：${it.why}`).join('；'),
								React.createElement('br'),
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-btn', disabled: running, style: { marginTop: '4px' }, onClick: forceRejectedBatch },
									`强制归档这 ${batchRejected.length} 条…`,
								),
							)
						: null,
					decay.length === 0
						? React.createElement('div', { className: 'tm-note' }, '没有衰减到该处理的条目。')
						: decay.map((it) => React.createElement(
								'div',
								{ key: it.id, className: 'tm-prow' },
								React.createElement('input', {
									type: 'checkbox',
									className: 'tm-check',
									checked: pendingSel[it.id] === true,
									disabled: running,
									onChange: () => setPendingSel((prev) => ({ ...prev, [it.id]: prev[it.id] !== true })),
								}),
								React.createElement('span', { className: 'tm-mono' }, it.id),
								React.createElement('span', { className: 'tm-tag' }, `强度 ${it.强度}`),
								React.createElement('span', { className: 'tm-preview', title: String(it.内容 ?? '') }, String(it.内容 ?? '') || '（无内容）'),
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-link', disabled: busy || running, onClick: () => markEntry('archive', it.id) },
									'归档',
								),
							)),
					React.createElement('h2', { className: 'tm-pane-t', style: { margin: '12px 0 6px' } }, '待晋升'),
					promote.length === 0
						? React.createElement('div', { className: 'tm-note' }, '还没有在 3 个以上不同项目里**验证**过的条目。')
						: promote.map((it) => React.createElement(
								'div',
								{ key: it.id, className: 'tm-prow' },
								React.createElement('span', { className: 'tm-mono' }, it.id),
								React.createElement('span', { className: 'tm-tag', title: '验证过它的独立项目数' }, `${it.项目数} 个项目验证`),
								React.createElement('span', { className: 'tm-preview', title: String(it.内容 ?? '') }, String(it.内容 ?? '') || '（无内容）'),
								React.createElement('span', { className: 'tm-note', title: `验证过它的项目：${String(it.已验证项目 ?? '') || '（无）'}` }, String(it.已验证项目 ?? '')),
								React.createElement(
									'button',
									{ type: 'button', className: 'tm-link', disabled: busy, onClick: () => markEntry('supersede', it.id, { 项目: '通用' }) },
									'晋升为通用',
								),
							)),
					// 三态拆分后必须说清「验证」的来路——V4 之前「被召回几次就记一个已验证项目」
					// 是错的，那句暗示要从界面上彻底拿掉，否则用户会以为被查得多就自动升级。
					React.createElement('div', { className: 'tm-note', style: { marginTop: '8px' } },
						'这两块都只是候选：归档和晋升都要人点一下才生效。批量归档也是逐条调、每条各留一份快照。'),
					promote.length > 0
						? React.createElement('div', { className: 'tm-note', style: { marginTop: '4px' } },
								'「已验证项目」= 用户确认过、或跨项目实测成功的项目。**单纯被召回查出来不算验证**，也不会让条目更容易晋升。')
						: null,
				)
			}

			/**
			 * 盘点清单（评审卡 kmvnul5vzxn7b 的界面入口；顺带把 `memory_review` 的四张清单
			 * 也摆出来——用户不开工具也该看得到库里有多少东西该整理）。
			 *
			 * **对后端字段缺失容错**：`召回失败未补` 是批B 新增的，旧宿主没有这一项；
			 * 没有就不摆那一块（而不是摆一个空壳让人以为「查过了、一条都没有」）。
			 * 每条清单只读，动作仍走归档/取代按钮——这里不新开写路径。
			 */
			function renderReviewPane() {
				const lists = [
					['衰减候选', Array.isArray(review?.衰减候选) ? review.衰减候选 : [], '强度低到该处理的（归档要人点）'],
					['晋升候选', Array.isArray(review?.晋升候选) ? review.晋升候选 : [], '在 3 个以上项目里验证过的（晋升要人点）'],
					['原文-总结未配对', Array.isArray(review?.原文总结未配对) ? review.原文总结未配对 : [], '总结条缺配套的原文条'],
					['缺口未补', Array.isArray(review?.缺口未补) ? review.缺口未补 : [], '立了缺口卡但还没补记'],
					// 批B：零命中落 misses 台账之后才有这一项。旧宿主没这字段 → 整块不出现。
					['召回失败未补', Array.isArray(review?.召回失败未补) ? review.召回失败未补 : null, '搜过但没命中、还没补标签的'],
				].filter(([, items]) => items !== null)
				const total = lists.reduce((n, [, items]) => n + items.length, 0)

				return React.createElement(
					'div',
					{ className: 'tm-card' },
					React.createElement(
						'button',
						{ type: 'button', className: 'tm-fold', onClick: () => setReviewOpen((v) => !v) },
						`${reviewOpen ? '▾' : '▸'} 盘点清单（整理工单）`,
						React.createElement('span', { className: 'tm-note' },
							review === null ? '点开才读' : review.ok === false ? '读取失败' : `共 ${total} 条待整理`),
					),
					reviewOpen
						? React.createElement(
								'div',
								{ style: { marginTop: '10px' } },
								review === null
									? React.createElement('div', { className: 'tm-note' }, '读取盘点清单…')
									: review.ok === false
										? React.createElement('div', { className: 'tm-note tm-err' }, `盘点读取失败：${review.error ?? '未知原因'}`)
										: lists.map(([name, items, hint]) => React.createElement(
												'div',
												{ key: name },
												React.createElement(
													'div',
													{ className: 'tm-pane-h' },
													React.createElement('h2', { className: 'tm-pane-t' }, name),
													React.createElement('span', { className: 'tm-mtag' }, `${items.length} 条`),
												),
												items.length === 0
													? React.createElement('div', { className: 'tm-note', style: { marginBottom: '8px' } }, `没有${name}。（${hint}）`)
													: React.createElement(
															'div',
															{ className: 'tm-revlist', style: { marginBottom: '10px' } },
															items.slice(0, 20).map((it) => React.createElement(
																'div',
																{ key: `${name}-${it.id}`, className: 'tm-prow' },
																React.createElement('span', { className: 'tm-mono' }, it.id ?? '—'),
																React.createElement('span', { className: 'tm-preview', title: String(it.内容 ?? '') }, String(it.内容 ?? '') || '（无内容）'),
																it.项目 ? React.createElement('span', { className: 'tm-tag' }, it.项目) : null,
															)),
															items.length > 20
																? React.createElement('div', { className: 'tm-note' }, `还有 ${items.length - 20} 条未列出。`)
																: null,
														),
											)),
								React.createElement('div', { className: 'tm-note', style: { marginTop: '4px' } },
									'这四张（批B 起五张）清单只是整理工单：归档、晋升都要人点一下才生效。'),
							)
						: null,
				)
			}

			function renderMaintenance() {
				const recent = bk !== null && Array.isArray(bk.recent) ? bk.recent : []
				const extra = bk !== null && Array.isArray(bk.log) ? bk.log.length : 0
				return React.createElement(
					'div',
					{ className: 'tm-card' },
					React.createElement(
						'button',
						{ type: 'button', className: 'tm-fold', onClick: () => setMaintOpen((v) => !v) },
						`${maintOpen ? '▾' : '▸'} 维护与状态（记忆文件托管 · 备份历史）`,
						React.createElement('span', { className: 'tm-note' }, `${hosted}/${files.length} 个记忆文件已托管 · 备份 ${bk?.copies ?? 0} 份${extra > 0 ? ` · 日志 ${extra} 行` : ''}`),
					),
					maintOpen
						? React.createElement(
								'div',
								{ style: { marginTop: '10px' } },
								React.createElement(
									'div',
									{ className: 'tm-pane-h' },
									React.createElement('h2', { className: 'tm-pane-t' }, '记忆文件托管'),
									React.createElement(
										'button',
										{ type: 'button', className: 'tm-btn', disabled: busy || !enabled, onClick: heal },
										busy ? '核对中…' : '核对并补回',
									),
								),
								React.createElement(
									'div',
									{ className: 'tm-note', style: { marginBottom: '8px' } },
									enabled
										? '这是给**别的智能体**看的一块说明：告诉它们这儿有一套标签记忆、怎么查、能存什么。你不用管也不用碰——每次挂载会自动核对，缺了就补回，块外面的内容一个字都不动。'
										: '记忆文件托管已关闭（config.notice=false）。',
								),
								note !== '' ? React.createElement('div', { className: 'tm-note', style: { marginBottom: '8px' } }, note) : null,
								files.length === 0
									? React.createElement('div', { className: 'tm-note' }, '没有探测到记忆文件。')
									: files.map((f) => React.createElement(
											'div',
											{ key: `${f.agent}/${f.file}`, className: 'tm-memrow' },
											React.createElement('span', {
												className: 'tm-dot',
												'data-ok': f.hasNotice ? 'true' : undefined,
												'data-missing': f.hasNotice ? undefined : 'true',
											}),
											React.createElement('span', null, `${f.agent}/${f.file}`),
											React.createElement('span', { className: 'tm-tag' },
												[f.hasNotice ? '已托管' : '缺块', f.backups > 0 ? `${f.backups} 个备份` : null].filter(Boolean).join(' · ')),
										)),
								React.createElement('h2', { className: 'tm-pane-t', style: { margin: '12px 0 6px' } }, '手上的备份'),
								recent.length === 0
									? React.createElement('div', { className: 'tm-note' }, '还没有备份。')
									: recent.map((row) => React.createElement(
											'div',
											{ key: row.stamp, className: 'tm-bkrow' },
											React.createElement('span', { className: 'tm-mono' }, row.stamp),
											React.createElement('span', null, row.at !== '' ? shortTime(row.at) : '—'),
											React.createElement('span', null, row.count !== null ? `${row.count} 条` : ''),
											row.label !== '' ? React.createElement('span', { className: 'tm-note' }, row.label) : null,
											React.createElement('span', { className: 'tm-tag' }, `${humanBytes(row.bytes)}${row.hasSchema === false ? ' · 无字典' : ''}${row.complete ? '' : ' · 不完整'}`),
										)),
							)
						: null,
				)
			}

			if (overview !== null && overview.ready === false) {
				const legacy = overview.legacy ?? null
				return React.createElement(
					'div',
					{ className: 'tm-root' },
					React.createElement('h1', { className: 'tm-head' }, SECTION_LABEL),
					React.createElement(
						'div',
						{ className: 'tm-card' },
						legacy !== null && legacy.legacyDetected === true
							? React.createElement(
									'div',
									{ className: 'tm-note tm-err' },
									'检测到旧库（旧版放在技能目录下的那一本），当前数据目录里还没有库。',
									React.createElement('br'),
									'插件不会自动搬库。要沿用旧记忆：把旧库整个拷到下面的数据目录，或把配置里的 dataDir 指到旧库所在处，然后重启 DSH。',
								)
							: React.createElement('div', { className: 'tm-note tm-err' }, '记忆库未就绪：找不到数据目录里的 store/memory.csv（首次启动会自动建库；建不出来多半是目录不可写）。'),
						React.createElement('div', { className: 'tm-note', style: { marginTop: '8px' } }, `数据目录：${overview.dataDir ?? overview.skillDir}`),
						React.createElement('div', { className: 'tm-note' }, `库文件：${overview.csvPath}`),
						legacy !== null && legacy.legacyDetected === true
							? React.createElement('div', { className: 'tm-note' }, `旧库位置：${legacy.legacyCsvPath}`)
							: null,
					),
				)
			}

			const notice = overview !== null ? overview.notice : null
			const enabled = notice !== null && notice.enabled !== false
			const files = notice !== null && Array.isArray(notice.files) ? notice.files : []
			const hosted = files.filter((f) => f.hasNotice).length

			const dims = overview !== null && Array.isArray(overview.dimensions) ? overview.dimensions : []
			const counts = overview !== null ? overview.byDimension ?? {} : {}
			// 格子数对不上的行：列按下标读，错位的那一行后面每格都串到别列上——
			// 表格看着照常有值，值是错的。这件事**必须**在页面上说出来，不能让人对着串了位的表做判断。
			const ragged = overview !== null && overview.health && Array.isArray(overview.health.ragged)
				? overview.health.ragged
				: []

			const hits = items
			const selectedCount = Object.keys(selected).length

			return React.createElement(
				'div',
				{ className: 'tm-root' },
				React.createElement(
					'div',
					{ className: 'tm-headrow' },
					React.createElement('h1', { className: 'tm-head' }, SECTION_LABEL),
					renderBarButtons(),
				),
				React.createElement(
					'div',
					{ className: 'tm-sub' },
					overview === null ? '读取中…' : `标签记忆库 · ${overview.csvPath}`,
				),
				renderBackupLine(),
				bkNote !== null
					? React.createElement('div', { className: `tm-note tm-${bkNote.kind === 'ok' ? 'ok' : 'bad'}` }, bkNote.text)
					: null,
				renderDirPane(),
				renderRestorePane(),
				renderMergePane(),

				ragged.length > 0
					? React.createElement(
							'div',
							{ className: 'tm-note tm-err' },
							`库里有 ${ragged.length} 行字段数对不上：${ragged.slice(0, 5).map((r) => `第 ${r.row} 条（${r.id || '没有 id'}，${r.got} 格 / 应为 ${r.want} 格）`).join('、')}${ragged.length > 5 ? ' 等' : ''}。`,
							React.createElement('br'),
							'列是按位置读的，这些行往后每一格都可能串到别的字段上——表里显示的值不可信。修好之前写入会被拒绝：把那一行补齐到与表头同样多的格子，或者用「恢复」退回上一份备份。',
						)
					: null,

				error !== null
					? React.createElement('div', { className: 'tm-note tm-err' }, `读取失败：${error}`)
					: null,

				overview === null
					? React.createElement('div', { className: 'tm-note' }, '读取概况…')
					: React.createElement(
							'div',
							{ className: 'tm-stats' },
							React.createElement(Stat, { value: overview.active, label: '生效条目' }),
							React.createElement(Stat, { value: overview.total, label: '总条目' }),
							React.createElement(Stat, { value: `${hosted}/${files.length}`, label: '记忆文件已托管' }),
							React.createElement(Stat, { value: dims.filter((d) => d.column !== null).length, label: '可筛维度' }),
						),

				// ── 记忆条目（主位：要看的 + 要筛要搜的，全在这一张卡里）──
				React.createElement(
					'div',
					{ className: 'tm-card' },
					React.createElement(
						'div',
						{ className: 'tm-card-h' },
						React.createElement('h2', { className: 'tm-card-t' }, '记忆条目'),
						React.createElement(
							'span',
							{ className: 'tm-note' },
							loading ? '读取中…' : `命中 ${total} 条${hits.length < total ? `（已示 ${hits.length}）` : ''}`,
						),
						Object.keys(cond).length > 0 || includeArchived
							? React.createElement(
									'button',
									{
										type: 'button',
										className: 'tm-btn',
										onClick: () => { setCond({}); setIncludeArchived(false) },
									},
									'清除条件',
								)
							: null,
						React.createElement(
							'button',
							{
								type: 'button',
								className: 'tm-btn',
								title: view === 'table' ? '换成一条一张的卡片' : '换成一行一条的表格',
								onClick: () => setView(view === 'table' ? 'cards' : 'table'),
							},
							view === 'table' ? '卡片视图' : '表格视图',
						),
						// ── V4-f 列设置：只对表格有意义（卡片没有列）。默认收起。 ──
						view === 'table'
							? React.createElement(
									'button',
									{
										type: 'button',
										className: 'tm-btn',
										'data-on': colOpen ? 'true' : undefined,
										title: '勾选表格里要显示哪些列（选择会记住）',
										onClick: () => setColOpen((v) => !v),
									},
									colOpen ? '收起列设置' : '列设置',
								)
							: null,
						// ── V4-d 手动刷新：别处写了库，点一下重取（不轮询，理由见 refreshAll） ──
						React.createElement(
							'button',
							{
								type: 'button',
								className: 'tm-btn',
								disabled: loading,
								title: '重新读取记忆库（别处写过库之后点这个）',
								onClick: refreshAll,
							},
							loading ? '刷新中…' : '刷新',
						),
					),
					// 列设置面板（次位：默认收起，展开才占地方）
					view === 'table' && colOpen ? renderColumnPicker() : null,
					// 维度下拉压成一行：选一个取值就叠一条条件（同维多值 = 或，维间 = 与）。
					React.createElement(
						'div',
						{ className: 'tm-filters', style: { marginBottom: '10px' } },
						dims.map((dim) => {
							const list = Object.entries(counts[dim.name] ?? {})
							const filterable = dim.column !== null && list.length > 0
							const trailing = dim.column === null ? '（未落列）' : list.length === 0 ? '（无数据）' : ''
							return React.createElement(
								'select',
								{
									key: dim.name,
									className: 'tm-select tm-fsel',
									value: '',
									disabled: !filterable,
									title: filterable ? `按「${dim.name}」叠加条件` : `「${dim.name}」不可筛选`,
									onChange: (event) => {
										if (event.target.value !== '') toggleDim(dim.name, event.target.value)
									},
								},
								React.createElement('option', { value: '' }, `${dim.name} ＋${trailing}`),
								// 已选中的值打 ✓；再选一次就是取消（toggleDim 本来就是开关）。
								list.map(([value, count]) =>
									React.createElement(
										'option',
										{ key: value, value },
										`${dimOn(dim.name, value) ? '✓ ' : ''}${value}（${count}）`,
									),
								),
							)
						}),
					),
					renderCrumbs(),
					React.createElement(
						'div',
						{ className: 'tm-field', style: { marginBottom: '10px' } },
						React.createElement('input', {
							className: 'tm-input',
							type: 'search',
							placeholder: '关键词（在命中的条目里全文搜）',
							value: q,
							ref: searchRef,
							onChange: (event) => setQ(event.target.value),
						}),
						React.createElement(
							'select',
							{ className: 'tm-select', value: effSort, onChange: (event) => setSort(event.target.value) },
							sortOptions.map(([value, text]) => React.createElement('option', { key: value, value }, text)),
						),
						React.createElement(
							'select',
							{ className: 'tm-select', value: String(limit), onChange: (event) => setLimit(parseInt(event.target.value, 10)) },
							PAGE_SIZES.map((n) => React.createElement('option', { key: n, value: String(n) }, `${n} 条`)),
						),
						React.createElement(
							'button',
							{
								type: 'button',
								className: 'tm-chip',
								'data-on': includeArchived ? 'true' : undefined,
								onClick: () => setIncludeArchived((value) => !value),
							},
							includeArchived ? '含已归档' : '不含已归档',
						),
					),
					React.createElement(
						'div',
						{ className: 'tm-tools' },
						React.createElement('button', { type: 'button', className: 'tm-btn', onClick: selectAllVisible }, '全选本页'),
						React.createElement('button', { type: 'button', className: 'tm-btn', onClick: () => setSelected({}) }, '清空选择'),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', disabled: selectedCount === 0, onClick: copySelected },
							'复制 Markdown',
						),
						React.createElement(
							'button',
							{ type: 'button', className: 'tm-btn', disabled: selectedCount === 0, onClick: exportSelected },
							'导出 CSV',
						),
						React.createElement('span', { className: 'tm-count' }, tip !== '' ? tip : `选中 ${selectedCount} 条`),
					),
					hits.length === 0
						? React.createElement(
								'div',
								{ className: 'tm-note' },
								loading ? '读取中…' : '没有命中。（默认排除 `被取代` / `已归档`，可点上面的「含已归档」看。）',
							)
						: view === 'table'
							? renderTable()
							: React.createElement(
									'div',
									{ className: 'tm-list' },
									hits.map((row, index) => renderItem(row, index)),
								),
					hits.length > 0
						? React.createElement(
								'button',
								{ type: 'button', className: 'tm-more', disabled: !hasMore || loadingMore, onClick: loadMore },
								hasMore ? (loadingMore ? '加载中…' : `加载更多（还有 ${total - hits.length} 条）`) : '已全部加载',
							)
						: null,
				),

				// ── 待整理 / 待晋升（V3，有候选才出现）──
				renderPending(),

				// ── 盘点清单（次位，默认收起：整理工单，含批B 的「召回失败未补」）──
				renderReviewPane(),

				// ── 维护与状态（次位，默认收起：托管 + 备份历史）──
				renderMaintenance(),
			)
		}

		/**
		 * 侧边栏那个按钮的图标。用内联 SVG，不去 require 平台的图标包——
		 * 少一个会随宿主版本漂移的依赖。
		 */
		function MemoryIcon(props) {
			const size = props !== null && props !== undefined && typeof props.size === 'number' ? props.size : 18
			return React.createElement(
				'svg',
				{
					width: size,
					height: size,
					viewBox: '0 0 24 24',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: 1.8,
					strokeLinecap: 'round',
					strokeLinejoin: 'round',
					'aria-hidden': 'true',
				},
				React.createElement('path', { d: 'M20.6 13.6 13.6 20.6a2 2 0 0 1-2.8 0L3 12.8V4a1 1 0 0 1 1-1h8.8l7.8 7.8a2 2 0 0 1 0 2.8Z' }),
				React.createElement('circle', { cx: '7.5', cy: '7.5', r: '1.4' }),
			)
		}

		/** 主区面板里的「记忆」页：加留白与限宽（设置页那份不需要），主区宽 → 默认表格。 */
		function MemoryPanel(props) {
			return React.createElement(
				'div',
				{ className: 'tm-panel' },
				React.createElement(MemorySection, { defaultView: 'table', pickDir: props?.pickDir, listDir: props?.listDir }),
			)
		}

		/**
		 * 设置页那一栏：**标签字典的只读展示**。
		 *
		 * 原来这里是把主区那套（条目表 + 筛选 + 备份 / 恢复 / 合并）原样搬过来一份，
		 * 窄栏里挤成一堆，用户看到的是「同一个东西出现了两次」。现在两边**各司其职**：
		 * 主区（侧边栏「记忆」）＝**库**（记了什么、怎么写新的）；这里＝**字典**（怎么判、按什么规则）。
		 *
		 * **只读是刻意的，不是没做完。** 字典是程序判定记忆的唯一依据：它每轮注入给这个 DSH 下的
		 * 所有智能体，还同时是写入校验的判据与筛选语义的来源——改一处等于改全库的读写。
		 * 所以这一版连一个可编辑控件都不放，只把字典**照实显示**出来。
		 */
		function MemoryDictPane() {
			const [dict, setDict] = React.useState(null)
			const [error, setError] = React.useState(null)

			React.useEffect(() => {
				let alive = true
				loadJSON(`${API}/dict`)
					.then((d) => { if (alive) setDict(d) })
					.catch((e) => { if (alive) setError(String(e?.message ?? e)) })
				return () => { alive = false }
			}, [])

			/** 一行取值：「取值本身」+「它是什么意思」。 */
			const valueRow = (v, i) => React.createElement(
				'div',
				{ key: `${v.value}#${i}`, className: 'tm-dict-item' },
				React.createElement('span', { className: 'tm-dict-val' }, v.value),
				v.desc !== '' ? React.createElement('span', { className: 'tm-dict-desc' }, v.desc) : null,
			)

			/** 一行「名目：说法」。没写就不摆一行空壳。 */
			const metaRow = (k, v) => (v === '' || v === null || v === undefined || v === false)
				? null
				: React.createElement(
						'div',
						{ className: 'tm-dict-item' },
						React.createElement('span', { className: 'tm-dict-val' }, k),
						React.createElement('span', { className: 'tm-dict-desc' }, String(v)),
					)

			/** 一个维度（或辅助列）一张卡：头顶标签，底下取值与判据。 */
			const dimCard = (d, key) => {
				const chips = []
				if (d.role !== '') chips.push(d.role)
				if (d.column === null) chips.push('未落列')
				else if (d.column !== d.name) chips.push(`落列：${d.column}`)
				if (d.required) chips.push('必填')
				if (d.cap !== null) chips.push(`上限 ${d.cap}`)
				if (d.status !== '') chips.push(d.status)
				const meta = [
					metaRow('何时判', d.when),
					metaRow('怎么判', d.how),
					metaRow('升降', d.lifts),
					metaRow('受谁管', d.gate === null ? '' : `${d.gate.when} → 否则${d.gate.otherwise}`),
					metaRow('留意', d.note),
				].filter(Boolean)
				return React.createElement(
					'div',
					{ key, className: 'tm-card' },
					React.createElement(
						'div',
						{ className: 'tm-card-h' },
						React.createElement('h2', { className: 'tm-card-t' }, d.name),
						chips.map((t, i) => React.createElement('span', { key: `c${i}`, className: 'tm-mtag' }, t)),
					),
					d.question !== '' ? React.createElement('div', { className: 'tm-dict-lead' }, d.question) : null,
					d.values.length > 0
						? React.createElement('div', { style: { marginTop: '4px' } }, d.values.map(valueRow))
						: null,
					d.text !== '' ? React.createElement('div', { className: 'tm-note', style: { marginTop: '6px' } }, d.text) : null,
					meta.length > 0 ? React.createElement('div', { style: { marginTop: '6px' } }, meta) : null,
				)
			}

			const ready = dict !== null && dict.ready === true
			const dims = ready && Array.isArray(dict.dimensions) ? dict.dimensions : []
			const aux = ready && Array.isArray(dict.auxiliary) ? dict.auxiliary : []
			const rules = ready && dict.rules !== null && typeof dict.rules === 'object' ? dict.rules : null
			const routes = ready && dict.writeRoutes !== null && typeof dict.writeRoutes === 'object' ? dict.writeRoutes : null
			const recall = ready && dict.recall !== null && typeof dict.recall === 'object' ? dict.recall : null

			return React.createElement(
				'div',
				{ className: 'tm-root' },
				React.createElement(
					'div',
					{ className: 'tm-headrow' },
					React.createElement('h1', { className: 'tm-head' }, SECTION_LABEL),
					React.createElement('span', { className: 'tm-mtag' }, '标签字典 · 只读'),
				),
				React.createElement(
					'div',
					{ className: 'tm-note' },
					'字典＝程序判定记忆的规则书：一条输入该不该记、每一维取什么值、筛选按什么算。它每轮注入给这台 DSH 下的所有智能体——改一处等于改全库的读写，所以本页只读。',
				),

				error !== null
					? React.createElement('div', { className: 'tm-note tm-err' }, `字典读取失败：${error}`)
					: null,

				dict === null
					? React.createElement('div', { className: 'tm-note' }, '读取字典…')
					: !ready
						? React.createElement(
								'div',
								{ className: 'tm-card' },
								React.createElement('div', { className: 'tm-note tm-err' }, dict.error ?? '字典读不出来。'),
								React.createElement('div', { className: 'tm-note', style: { marginTop: '8px' } }, `字典位置：${dict.path}`),
							)
						: React.createElement(
								React.Fragment,
								null,
								dict.stale === true
									? React.createElement('div', { className: 'tm-note tm-warn' }, '⚠ 磁盘上的字典已经改过，宿主还在用启动时装载的那一份——重启 DSH 才会生效。')
									: null,
								React.createElement(
									'div',
									{ className: 'tm-sub' },
									`来源：${dict.path}　·　改动时间 ${dict.mtime === null ? '（读不到）' : shortTime(dict.mtime)}${dict.version === '' ? '' : `　·　版本 ${dict.version}`}`,
								),

								React.createElement('h2', { className: 'tm-pane-t' }, '四个维度（写入时必判）'),
								dims.map((d, i) => dimCard(d, `dim${i}`)),

								aux.length > 0
									? React.createElement(
											'div',
											{ className: 'tm-card' },
											React.createElement(
												'div',
												{ className: 'tm-card-h' },
												React.createElement('h2', { className: 'tm-card-t' }, '辅助列'),
												React.createElement('span', { className: 'tm-mtag' }, '随条记，不单独当维度筛'),
											),
											aux.map((a, i) => React.createElement(
												'div',
												{ key: `aux${i}` },
												React.createElement(
													'div',
													{ className: 'tm-dict-item' },
													React.createElement('span', { className: 'tm-dict-val' }, `${a.name}${a.column === null ? '（未落列）' : ''}${a.required ? ' · 必填' : ''}`),
													React.createElement('span', { className: 'tm-dict-desc' }, a.question),
												),
												a.values.length > 0
													? React.createElement('div', { style: { paddingLeft: '10px' } }, a.values.map(valueRow))
													: null,
												a.text !== '' ? React.createElement('div', { className: 'tm-note', style: { paddingLeft: '10px' } }, a.text) : null,
												a.note !== '' ? React.createElement('div', { className: 'tm-note', style: { paddingLeft: '10px' } }, a.note) : null,
											)),
										)
									: null,

								rules !== null
									? React.createElement(
											'div',
											{ className: 'tm-card' },
											React.createElement(
												'div',
												{ className: 'tm-card-h' },
												React.createElement('h2', { className: 'tm-card-t' }, '通用规则'),
											),
											React.createElement(
												'div',
												null,
												metaRow('必填', rules.required.join(' / ')),
												metaRow('留白', rules.blank),
												metaRow('白名单', rules.universalValue === '' ? rules.universal : `\`${rules.universalValue}\`：${rules.universal}`),
												metaRow('筛选算子', rules.operators.join(' / ')),
												metaRow('分工', rules.model),
											),
										)
									: null,

								routes !== null && routes.rules.length > 0
									? React.createElement(
											'div',
											{ className: 'tm-card' },
											React.createElement(
												'div',
												{ className: 'tm-card-h' },
												React.createElement('h2', { className: 'tm-card-t' }, '写入路由（先判是哪一类输入，再决定写几条）'),
											),
											routes.rules.map((t, i) => React.createElement(
												'div',
												{ key: `wr${i}`, className: 'tm-dict-item' },
												React.createElement('span', { className: 'tm-dict-rule' }, String(i + 1)),
												React.createElement('span', { className: 'tm-dict-desc' }, t),
											)),
										)
									: null,

								recall !== null && (recall.order.length > 0 || recall.miss !== '')
									? React.createElement(
											'div',
											{ className: 'tm-card' },
											React.createElement(
												'div',
												{ className: 'tm-card-h' },
												React.createElement('h2', { className: 'tm-card-t' }, '召回口径'),
												recall.takeFirst === null ? null : React.createElement('span', { className: 'tm-mtag' }, `先报总数，再取前 ${recall.takeFirst} 条`),
											),
											recall.order.map((t, i) => React.createElement(
												'div',
												{ key: `rc${i}`, className: 'tm-dict-item' },
												React.createElement('span', { className: 'tm-dict-rule' }, String(i + 1)),
												React.createElement('span', { className: 'tm-dict-desc' }, t),
											)),
											metaRow('时间筛', recall.timeFilter),
											metaRow('没命中', recall.miss),
											// 三态拆分（卡 kmvnul5yka32f）：召回只是「读」，不写库、不改强度。
											// 这句是给用户看的，字典文件里没有这一项（那是后端口径），
											// 所以放在界面层说明，不改字典内容。
											React.createElement(
												'div',
												{ className: 'tm-note', style: { marginTop: '6px' } },
												'召回只是读：查到一条不会让它变强、也不等于它被验证过。只有真正用它回答了问题才算「使用」，只有用户确认或跨项目实测成功才算「验证」。',
											),
										)
									: null,

								React.createElement(
									'div',
									{ className: 'tm-note tm-warn' },
									'改字典＝改规则，本页不开放编辑。要改就直接编辑上面那个文件（改前自己留一份），改完重启 DSH 才生效。条目浏览与备份 / 恢复 / 合并都在侧边栏的「记忆」页。',
								),
							),
			)
		}

		exports.name = 'tag-memory'
		exports.inject = ['slots']

		exports.apply = function apply(ctx) {
			const slots = ctx.slots ?? ctx.get('slots')
			if (slots === undefined || slots === null) return

			// 页面样式属于插件资源：在 apply 里登记，卸载/HMR 时由 effect 回收。
			const disposeStyles = ensureStyles()
			if (typeof ctx.effect === 'function') ctx.effect(() => disposeStyles)

			/**
			 * 取 DSH 的目录选择服务（`uiWorkspace`）。
			 *
			 * **只能走 `ctx.get('uiWorkspace')`，绝不能写 `ctx.uiWorkspace`。**
			 * cordis 的属性访问是顺着**本 fiber 的祖先链**往上找的（vendor/cordis/src/reflect.ts 里
			 * `ReflectService.handler.get` 那个 while 循环）：`uiWorkspace` 是**别的插件在兄弟 fiber 上**
			 * 提供的，不在本插件的祖先链里，找不到就**抛** `cannot get property "uiWorkspace" without inject`
			 * ——写在 `??` 左边的话右边根本没机会跑，整句直接炸。
			 * 官方 `ui-directory-picker-native` 敢写 `ctx.uiWorkspace`，是因为它把 `uiWorkspace`
			 * 写进了自己的 `inject`；本插件不写 inject（不想给「没有这服务的 DSH」加硬依赖），
			 * 所以必须用那条不看 fiber 位置的读法——`ReflectService.get` 的注释原文就是
			 * “Read a service from the store without the inject requirement”。
			 *
			 * 拿不到就抛，界面退回内建目录浏览 / 手填。
			 */
			const workspace = () => {
				const ws = ctx.get?.('uiWorkspace')
				if (ws === undefined || ws === null) {
					throw new Error('这个 DSH 没挂目录选择服务（uiWorkspace）——手填绝对路径吧。')
				}
				return ws
			}
			const pickDir = async () => await workspace().pickDirectory()
			const listDir = async (path) => await workspace().listDirectory(path)

			// ① 主区面板：侧边栏按钮切过去的就是这一页。
			slots.inject('main', () =>
				slots.register({ name: 'main', key: PANEL_ID, inject: () => ({ pickDir, listDir }) }, MemoryPanel),
			)

			// ② 侧边栏按钮：紧挨在官方「插件」按钮（order 0）下面。
			slots.inject('sidebar.panellist', () =>
				slots.register(
					{ name: 'sidebar.panellist', id: PANEL_ID, order: PANEL_ORDER, label: () => SECTION_LABEL },
					MemoryIcon,
				),
			)

			// ③ 设置里也留一栏：**标签字典的只读展示**（跟主区那份各司其职——那边是库，这边是规则）。
			//    它不碰目录选择服务，所以**不注入 pickDir / listDir**（用不上的注入等于白担一份依赖）。
			slots.inject('settings.section', () =>
				slots.register(
					{ name: 'settings.section', id: SECTION_ID, order: 60, label: () => SECTION_LABEL },
					MemoryDictPane,
				),
			)
		}

		return module.exports
	},
})
